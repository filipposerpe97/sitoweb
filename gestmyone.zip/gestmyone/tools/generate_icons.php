<?php
// Simple icon generator using GD, creates multiple PNG sizes and a favicon.ico (16/32) embedding PNGs.
$base = realpath(__DIR__ . '/../');
$source = $base . '/public/assets/myone-logo.png';
$outDir = $base . '/public/assets';
$icoOut = $base . '/public/favicon.ico';

if (!file_exists($source)) {
    fwrite(STDERR, "Source not found: $source\n");
    exit(1);
}

function ensureDir($dir){ if(!is_dir($dir)) mkdir($dir, 0777, true); }
function resizePng($srcPath, $dstPath, $size){
    $src = imagecreatefrompng($srcPath);
    if(!$src){ throw new RuntimeException('Cannot load PNG: '.$srcPath); }
    $w = imagesx($src); $h = imagesy($src);
    $dst = imagecreatetruecolor($size, $size);
    imagealphablending($dst, false); imagesavealpha($dst, true);
    $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
    imagefill($dst, 0, 0, $transparent);
    // fit contain
    $scale = min($size/$w, $size/$h);
    $nw = (int)round($w*$scale); $nh = (int)round($h*$scale);
    $dx = (int)(($size-$nw)/2); $dy = (int)(($size-$nh)/2);
    imagecopyresampled($dst, $src, $dx, $dy, 0, 0, $nw, $nh, $w, $h);
    imagepng($dst, $dstPath, 9);
    imagedestroy($src); imagedestroy($dst);
}

function buildIcoFromPngs(array $pngFiles, $dest){
    // ICO with PNG-compressed images per entry
    $entries = [];
    $dataBlocks = [];
    $offset = 6 + 16 * count($pngFiles);
    foreach($pngFiles as $path){
        $data = file_get_contents($path);
        if($data === false){ throw new RuntimeException('Cannot read: '.$path); }
        $size = getimagesize($path);
        $w = $size[0]; $h = $size[1];
        $wByte = $w >= 256 ? 0 : $w; // 0 means 256
        $hByte = $h >= 256 ? 0 : $h;
        $bytesInRes = strlen($data);
        $entries[] = pack('CCCCvvVV', $wByte, $hByte, 0, 0, 1, 32, $bytesInRes, $offset);
        $dataBlocks[] = $data;
        $offset += $bytesInRes;
    }
    $header = pack('vvv', 0, 1, count($pngFiles));
    $ico = $header . implode('', $entries) . implode('', $dataBlocks);
    file_put_contents($dest, $ico);
}

ensureDir($outDir);

$targets = [
    ['path' => $outDir.'/favicon-16.png', 'size' => 16],
    ['path' => $outDir.'/favicon-32.png', 'size' => 32],
    ['path' => $outDir.'/apple-touch-icon-180.png', 'size' => 180],
    ['path' => $outDir.'/android-chrome-192x192.png', 'size' => 192],
    ['path' => $outDir.'/android-chrome-256x256.png', 'size' => 256],
    ['path' => $outDir.'/android-chrome-512x512.png', 'size' => 512],
];

foreach($targets as $t){
    resizePng($source, $t['path'], $t['size']);
}

buildIcoFromPngs([
    $outDir.'/favicon-16.png',
    $outDir.'/favicon-32.png',
], $icoOut);

echo "Generated icons in $outDir and ICO at $icoOut\n";