<?php
// Front Controller
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('BASE_PATH', dirname(__DIR__));

// Carica autoload di Composer se presente (per Dompdf e altre dipendenze)
if (file_exists(BASE_PATH . '/vendor/autoload.php')) {
    require BASE_PATH . '/vendor/autoload.php';
}

// Sessions
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Simple PSR-4 like autoloader for app namespace
spl_autoload_register(function ($class) {
    $baseDir = BASE_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR;
    $class = str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $class);
    $file = $baseDir . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Load config
$GLOBALS['config'] = require BASE_PATH . '/config/app.php';

// Utilities
function render(string $view, array $params = [])
{
    $config = $GLOBALS['config'];
    extract($params);
    ob_start();
    require BASE_PATH . '/app/Views/' . $view . '.php';
    $content = ob_get_clean();
    require BASE_PATH . '/app/Views/layout.php';
}

// Rendering per wizard installazione (usa view completa, senza layout app)
function render_install(string $view, array $params = [])
{
    extract($params);
    require BASE_PATH . '/app/Views/' . $view . '.php';
}

function redirect(string $to): void { header('Location: ' . $to); exit; }

// Ensure storage exists
if (!is_dir(BASE_PATH . '/storage')) {
    mkdir(BASE_PATH . '/storage', 0777, true);
}

$installed = is_file(BASE_PATH . '/storage/.installed');

require_once BASE_PATH . '/app/Core/DB.php';
require_once BASE_PATH . '/app/Core/Router.php';

use App\Core\Router;

// Se NON installato: attiva solo il wizard di installazione e non inizializzare il DB
if (!$installed) {
    Router::get('/install', 'InstallController@db');
    Router::post('/install', 'InstallController@dbPost');
    Router::post('/install/test-db', 'InstallController@testDb');
    Router::get('/install/company', 'InstallController@company');
    Router::post('/install/company', 'InstallController@companyPost');
    Router::get('/install/admin', 'InstallController@admin');
    Router::post('/install/admin', 'InstallController@adminPost');
    Router::get('/install/finish', 'InstallController@finish');
    Router::post('/install/finish', 'InstallController@finishPost');

    // Dispatch e stop
    Router::dispatch($_SERVER['REQUEST_URI'], $_SERVER['REQUEST_METHOD']);
    return;
}

// Init DB and run initial migration
App\Core\DB::init($GLOBALS['config']['db']);
$schemaFile = ($GLOBALS['config']['db']['driver'] ?? 'sqlite') === 'mysql'
    ? BASE_PATH . '/database/schema.mysql.sql'
    : BASE_PATH . '/database/schema.sql';
App\Core\DB::migrate($schemaFile);
App\Core\DB::ensureUserPasswordColumns();

// Seed utente admin di default se mancano utenti
try {
    $exists = (int)(App\Core\DB::query('SELECT COUNT(*) c FROM users')->fetch()['c'] ?? 0);
    if ($exists === 0) {
        // Assicura che i ruoli esistano (in SQLite potrebbero non esserci)
        try {
            App\Core\DB::execute("INSERT OR IGNORE INTO roles (name, description) VALUES ('admin','Amministratore')");
        } catch (\Throwable $e) {}
        $roleId = App\Core\DB::query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1")->fetch()['id'] ?? null;
        if (!$roleId) {
            App\Core\DB::execute("INSERT INTO roles (name, description) VALUES ('admin','Amministratore')");
            $roleId = App\Core\DB::pdo()->lastInsertId();
        }
        $pass = password_hash('ChangeMe!123', PASSWORD_BCRYPT);
        App\Core\DB::execute('INSERT INTO users (role_id, name, email, password, must_change_password, active) VALUES (?,?,?,?,1,1)', [
            $roleId, 'Admin', 'admin@local', $pass
        ]);
    }
} catch (\Throwable $e) {
    // ignore
}

// Auth routes
Router::get('/login', 'AuthController@login');
Router::post('/login', 'AuthController@doLogin');
Router::get('/logout', 'AuthController@logout');

// Protected routes middleware (simple)
$publicPaths = ['/login', '/install', '/password/change'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (!in_array($path, $publicPaths, true) && empty($_SESSION['user'])) {
    redirect('/login');
}
// Enforce cambio password al primo accesso
if (!empty($_SESSION['user']) && !empty($_SESSION['must_change_password'])) {
    if ($path !== '/password/change' && $path !== '/logout') {
        redirect('/password/change');
    }
}

// Routes
Router::get('/', 'HomeController@index');
Router::get('/dealers', function () { render('placeholder', ['page_title' => 'Concessionari']); });
Router::get('/stores', function () { render('placeholder', ['page_title' => 'Punti Vendita']); });
Router::get('/rooms', function () { render('placeholder', ['page_title' => 'Sale']); });
Router::get('/terminals', function () { render('placeholder', ['page_title' => 'Terminali']); });
Router::get('/peripherals', function () { render('placeholder', ['page_title' => 'Periferiche']); });
Router::get('/tickets', function () { render('placeholder', ['page_title' => 'Ticket & Interventi']); });
Router::get('/reports', function () { render('placeholder', ['page_title' => 'Report & Esportazioni']); });

// Gestione Password
Router::get('/password/change', 'PasswordController@change');
Router::post('/password/change', 'PasswordController@changePost');

// Gestione Utenti
Router::get('/users', 'UsersController@index');
Router::get('/users/create', 'UsersController@create');
Router::post('/users', 'UsersController@store');
Router::get('/users/edit', 'UsersController@edit');
Router::post('/users/update', 'UsersController@update');
Router::post('/users/toggle', 'UsersController@toggle');
Router::post('/users/reset-password', 'UsersController@resetPassword');
Router::get('/users/pdf', 'UsersController@pdf');
Router::get('/users/pdf-download', 'UsersController@pdfDownload');
Router::get('/users/export', 'UsersController@export');

Router::get('/profile', 'AuthController@profile');

// Dispatch
Router::dispatch($_SERVER['REQUEST_URI'], $_SERVER['REQUEST_METHOD']);