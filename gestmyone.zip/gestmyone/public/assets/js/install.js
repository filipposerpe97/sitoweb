document.addEventListener('DOMContentLoaded', () => {
  // STEP 1: DB (db.php)
  const driverSel = document.getElementById('driver');
  const mysqlFields = document.getElementById('mysqlFields');
  const sqliteFields = document.getElementById('sqliteFields');
  const reqMysqlInputs = ['host', 'port', 'database', 'username'];

  function toggleDriver() {
    if (!driverSel || !mysqlFields || !sqliteFields) return;
    const v = driverSel.value;
    const mysql = v === 'mysql';
    mysqlFields.classList.toggle('d-none', !mysql);
    sqliteFields.classList.toggle('d-none', mysql);
    reqMysqlInputs.forEach(name => {
      const el = document.querySelector(`[name="${name}"]`);
      if (el) el.required = mysql;
    });
  }

  if (driverSel) {
    driverSel.addEventListener('change', toggleDriver);
    toggleDriver();
  }

  const testBtn = document.getElementById('testBtn');
  if (testBtn) {
    testBtn.addEventListener('click', async function () {
      const form = document.getElementById('dbForm');
      const data = Object.fromEntries(new FormData(form).entries());
      const payload = { driver: data.driver };
      if (data.driver === 'mysql') {
        payload.mysql = {
          host: data.host,
          port: Number(data.port || 3306),
          database: data.database,
          username: data.username,
          password: data.password
        };
      } else {
        payload.sqlite_path = data.sqlite_path;
      }
      const out = document.getElementById('testResult');
      out.textContent = 'Verifica connessione...';
      out.className = 'ms-auto small text-muted';
      try {
        const res = await fetch('/install/test-db', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const json = await res.json();
        if (json.ok) {
          out.textContent = 'Connessione OK';
          out.className = 'ms-auto small text-success';
        } else {
          out.textContent = 'Errore: ' + (json.error || 'Impossibile connettere');
          out.className = 'ms-auto small text-danger';
        }
      } catch (e) {
        out.textContent = 'Errore di rete';
        out.className = 'ms-auto small text-danger';
      }
    });
  }

  // STEP 2: Company (company.php) - brand colors preview + logo preview
  const primaryInput = document.querySelector('input[name="brand_primary"]');
  const secondaryInput = document.querySelector('input[name="brand_secondary"]');
  function applyTheme() {
    if (primaryInput) document.documentElement.style.setProperty('--brand-primary', primaryInput.value || '#0d6efd');
    if (secondaryInput) document.documentElement.style.setProperty('--brand-secondary', secondaryInput.value || '#6610f2');
  }
  if (primaryInput) primaryInput.addEventListener('input', applyTheme);
  if (secondaryInput) secondaryInput.addEventListener('input', applyTheme);
  if (primaryInput || secondaryInput) applyTheme();

  const logoInput = document.querySelector('input[name="company_logo"]');
  const logoPreview = document.getElementById('logoPreview');
  if (logoInput && logoPreview) {
    logoInput.addEventListener('change', function(){
      const f = this.files && this.files[0];
      if (!f) { logoPreview.style.display = 'none'; return; }
      const reader = new FileReader();
      reader.onload = (e) => {
        logoPreview.src = e.target.result;
        logoPreview.style.display = 'inline-block';
      };
      reader.readAsDataURL(f);
    });
  }

  // STEP 3: Admin (admin.php) - password match validation
  const adminForm = document.getElementById('adminForm');
  const p1 = document.getElementById('password');
  const p2 = document.getElementById('password_confirm');
  const mismatch = document.getElementById('pwMismatch');
  if (adminForm && p1 && p2 && mismatch) {
    const submitBtn = adminForm.querySelector('button[type="submit"]');
    function validatePw(){
      const ok = p1.value.length >= 6 && p1.value === p2.value;
      mismatch.classList.toggle('d-none', ok);
      if (submitBtn) submitBtn.disabled = !ok;
    }
    p1.addEventListener('input', validatePw);
    p2.addEventListener('input', validatePw);
    validatePw();
  }
});