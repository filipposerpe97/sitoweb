-- MySQL schema iniziale esteso
CREATE TABLE IF NOT EXISTS companies (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NULL,
  phone VARCHAR(60) NULL,
  address VARCHAR(255) NULL,
  logo_url VARCHAR(255) NULL,
  brand_primary VARCHAR(20) DEFAULT '#0d6efd',
  brand_secondary VARCHAR(20) DEFAULT '#6610f2',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dealers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  dealer_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  address VARCHAR(255),
  city VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_stores_dealer FOREIGN KEY (dealer_id) REFERENCES dealers(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rooms (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  store_id INT UNSIGNED NOT NULL,
  name VARCHAR(120) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rooms_store FOREIGN KEY (store_id) REFERENCES stores(id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS terminals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  store_id INT UNSIGNED NOT NULL,
  room_id INT UNSIGNED NULL,
  model VARCHAR(120),
  serial VARCHAR(120) UNIQUE,
  status ENUM('attivo','spedito','in_attivazione','in_swap','fuori_servizio','dismesso') DEFAULT 'attivo',
  installed_at DATETIME NULL,
  warranty_end DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_terminals_store FOREIGN KEY (store_id) REFERENCES stores(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_terminals_room FOREIGN KEY (room_id) REFERENCES rooms(id)
    ON UPDATE SET NULL ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS partners (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  type ENUM('tecnici','riparazioni') DEFAULT 'tecnici',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS roles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) UNIQUE NOT NULL,
  description VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_id INT UNSIGNED NOT NULL,
  dealer_id INT UNSIGNED NULL,
  partner_id INT UNSIGNED NULL,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  username VARCHAR(100) UNIQUE NULL,
  password VARCHAR(255) NOT NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  password_changed_at DATETIME NULL,
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT fk_users_dealer FOREIGN KEY (dealer_id) REFERENCES dealers(id),
  CONSTRAINT fk_users_partner FOREIGN KEY (partner_id) REFERENCES partners(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS peripherals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  type VARCHAR(120) NOT NULL,
  model VARCHAR(120) NOT NULL,
  serial VARCHAR(120) UNIQUE,
  status ENUM('installata','magazzino','guasta','riparazione','dismessa') DEFAULT 'magazzino',
  current_terminal_id INT UNSIGNED NULL,
  warranty_end DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_peripherals_terminal FOREIGN KEY (current_terminal_id) REFERENCES terminals(id)
    ON UPDATE SET NULL ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tickets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  terminal_id INT UNSIGNED NOT NULL,
  type ENUM('onsite','remoto','spedizione') DEFAULT 'onsite',
  subject VARCHAR(200),
  description TEXT,
  status ENUM('aperto','in_lavorazione','attesa_ricambi','chiuso') DEFAULT 'aperto',
  opened_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  closed_at DATETIME NULL,
  created_by INT UNSIGNED NULL,
  CONSTRAINT fk_tickets_terminal FOREIGN KEY (terminal_id) REFERENCES terminals(id),
  CONSTRAINT fk_tickets_user FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS interventions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL,
  kind ENUM('onsite','remoto','spedizione') NOT NULL,
  technician_id INT UNSIGNED NULL,
  scheduled_at DATETIME NULL,
  performed_at DATETIME NULL,
  outcome VARCHAR(255) NULL,
  notes TEXT NULL,
  CONSTRAINT fk_interventions_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id),
  CONSTRAINT fk_interventions_technician FOREIGN KEY (technician_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS repairs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  peripheral_id INT UNSIGNED NOT NULL,
  partner_id INT UNSIGNED NULL,
  status ENUM('ritiro','in_diagnosi','preventivo','approvata','riparata','restituita','scartata') DEFAULT 'ritiro',
  estimate_amount DECIMAL(10,2) NULL,
  approved TINYINT(1) DEFAULT 0,
  shipped_at DATETIME NULL,
  returned_at DATETIME NULL,
  notes TEXT,
  CONSTRAINT fk_repairs_peripheral FOREIGN KEY (peripheral_id) REFERENCES peripherals(id),
  CONSTRAINT fk_repairs_partner FOREIGN KEY (partner_id) REFERENCES partners(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS peripheral_replacements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NULL,
  terminal_id INT UNSIGNED NOT NULL,
  old_peripheral_id INT UNSIGNED NULL,
  new_peripheral_id INT UNSIGNED NOT NULL,
  replaced_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  notes TEXT,
  CONSTRAINT fk_repl_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id),
  CONSTRAINT fk_repl_terminal FOREIGN KEY (terminal_id) REFERENCES terminals(id),
  CONSTRAINT fk_repl_old FOREIGN KEY (old_peripheral_id) REFERENCES peripherals(id),
  CONSTRAINT fk_repl_new FOREIGN KEY (new_peripheral_id) REFERENCES peripherals(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ruoli base
INSERT INTO roles (name, description) VALUES
  ('admin','Amministratore'),
  ('concessionario','Account del concessionario'),
  ('partner','Azienda partner'),
  ('tecnico','Tecnico sul territorio'),
  ('store_manager_readonly','Responsabile punto vendita (sola lettura)')
ON DUPLICATE KEY UPDATE description = VALUES(description);