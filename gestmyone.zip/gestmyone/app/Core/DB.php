<?php
namespace App\Core;

use PDO;
use PDOException;

class DB
{
    protected static ?PDO $pdo = null;

    public static function init(array $dbConfig): void
    {
        try {
            if (($dbConfig['driver'] ?? 'sqlite') === 'mysql') {
                $mysql = $dbConfig['mysql'];
                $charset = $mysql['charset'] ?? 'utf8mb4';
                $collation = $mysql['collation'] ?? 'utf8mb4_general_ci';
                // Primo tentativo: connessione al server senza DB per creare il database se manca
                $serverDsn = sprintf('mysql:host=%s;port=%s;charset=%s', $mysql['host'], $mysql['port'], $charset);
                $serverPdo = new PDO($serverDsn, $mysql['username'], $mysql['password'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
                $serverPdo->exec(sprintf('CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET %s COLLATE %s',
                    str_replace('`','``',$mysql['database']), $charset, $collation));
                // Connessione al database specifico
                $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s', $mysql['host'], $mysql['port'], $mysql['database'], $charset);
                self::$pdo = new PDO($dsn, $mysql['username'], $mysql['password'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
                self::$pdo->exec('SET NAMES '.$charset.' COLLATE '.$collation);
            } else {
                $sqlitePath = $dbConfig['sqlite_path'] ?? (BASE_PATH . '/storage/data.sqlite');
                $dsn = 'sqlite:' . $sqlitePath;
                self::$pdo = new PDO($dsn, null, null, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo 'Errore connessione DB: ' . htmlspecialchars($e->getMessage());
            exit;
        }
    }

    public static function pdo(): PDO
    {
        if (!self::$pdo) {
            throw new \RuntimeException('DB non inizializzato');
        }
        return self::$pdo;
    }

    public static function query(string $sql, array $params = [])
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function execute(string $sql, array $params = []): bool
    {
        $stmt = self::pdo()->prepare($sql);
        return $stmt->execute($params);
    }

    public static function migrate(string $schemaFile): void
    {
        if (!is_dir(BASE_PATH . '/storage')) {
            mkdir(BASE_PATH . '/storage', 0777, true);
        }
        $driver = self::pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
        $flag = BASE_PATH . '/storage/.initialized_' . md5($schemaFile . '|' . $driver);
        if (file_exists($flag)) {
            return;
        }
        if (!file_exists($schemaFile)) {
            file_put_contents($flag, date('c'));
            return;
        }
        $sql = file_get_contents($schemaFile);
        $parts = preg_split('/;\s*(?:\r?\n|$)/', $sql);
        $statements = array_values(array_filter(array_map('trim', $parts), fn($s) => $s !== ''));

        try {
            if ($driver === 'sqlite') {
                self::pdo()->beginTransaction();
            }
            foreach ($statements as $statement) {
                if ($statement !== '') {
                    self::pdo()->exec($statement);
                }
            }
            if ($driver === 'sqlite' && self::pdo()->inTransaction()) {
                self::pdo()->commit();
            }
            file_put_contents($flag, date('c'));
        } catch (\Throwable $e) {
            if ($driver === 'sqlite' && self::pdo()->inTransaction()) {
                self::pdo()->rollBack();
            }
            http_response_code(500);
            echo 'Errore migrazione DB: ' . htmlspecialchars($e->getMessage());
            exit;
        }
    }

    // --- Upgrade helpers ---
    public static function columnExists(string $table, string $column): bool
    {
        $driver = self::pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
        if ($driver === 'mysql') {
            $sql = "SELECT COUNT(*) c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?";
            $row = self::query($sql, [$table, $column])->fetch();
            return (int)($row['c'] ?? 0) > 0;
        }
        // sqlite
        $cols = self::query('PRAGMA table_info(' . $table . ')')->fetchAll();
        foreach ($cols as $c) {
            if (strcasecmp($c['name'] ?? $c['Name'] ?? '', $column) === 0) return true;
        }
        return false;
    }

    public static function ensureUserPasswordColumns(): void
    {
        $driver = self::pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
        // must_change_password
        if (!self::columnExists('users', 'must_change_password')) {
            if ($driver === 'mysql') {
                self::pdo()->exec("ALTER TABLE users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0 AFTER password");
            } else {
                self::pdo()->exec("ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0");
            }
        }
        // password_changed_at
        if (!self::columnExists('users', 'password_changed_at')) {
            if ($driver === 'mysql') {
                self::pdo()->exec("ALTER TABLE users ADD COLUMN password_changed_at DATETIME NULL AFTER must_change_password");
            } else {
                self::pdo()->exec("ALTER TABLE users ADD COLUMN password_changed_at TEXT NULL");
            }
        }
    }
}