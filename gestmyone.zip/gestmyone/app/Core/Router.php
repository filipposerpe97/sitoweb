<?php
namespace App\Core;

class Router
{
    protected static array $routes = [
        'GET' => [],
        'POST' => [],
    ];

    public static function get(string $path, $handler): void
    {
        self::$routes['GET'][self::normalize($path)] = $handler;
    }

    public static function post(string $path, $handler): void
    {
        self::$routes['POST'][self::normalize($path)] = $handler;
    }

    public static function dispatch(string $uri, string $method): void
    {
        $method = strtoupper($method);
        $path = parse_url($uri, PHP_URL_PATH);
        $path = self::normalize($path);

        $handler = self::$routes[$method][$path] ?? null;
        if (!$handler) {
            http_response_code(404);
            echo '<h1>404</h1><p>Pagina non trovata</p>';
            return;
        }

        if (is_callable($handler)) {
            echo call_user_func($handler);
            return;
        }

        if (is_string($handler) && strpos($handler, '@') !== false) {
            [$controller, $action] = explode('@', $handler, 2);
            $fqcn = 'App\\Controllers\\' . $controller;
            $file = BASE_PATH . '/app/Controllers/' . $controller . '.php';
            if (file_exists($file)) {
                require_once $file;
            }
            if (!class_exists($fqcn)) {
                http_response_code(500);
                echo 'Controller non trovato';
                return;
            }
            $instance = new $fqcn();
            if (!method_exists($instance, $action)) {
                http_response_code(500);
                echo 'Azione non trovata';
                return;
            }
            echo call_user_func([$instance, $action]);
            return;
        }

        http_response_code(500);
        echo 'Handler non valido';
    }

    protected static function normalize(string $path): string
    {
        $path = rtrim($path, '/');
        return $path === '' ? '/' : $path;
    }
}