<?php
namespace App\Controllers;

use App\Core\DB;

class InstallController
{
    // STEP 1: Configurazione Database
    public function db()
    {
        $config = $GLOBALS['config'];
        $errors = $_SESSION['install_errors']['db'] ?? [];
        unset($_SESSION['install_errors']['db']);
        $env = $this->getEnvWarnings();
        render_install('install/db', compact('config','errors','env'));
        return '';
    }

    public function testDb()
    {
        header('Content-Type: application/json');
        $input = json_decode(file_get_contents('php://input'), true) ?: [];
        $driver = $input['driver'] ?? 'mysql';
        try {
            if ($driver === 'mysql') {
                $mysql = $input['mysql'] ?? [];
                $charset = $mysql['charset'] ?? 'utf8mb4';
                $dsn = sprintf('mysql:host=%s;port=%s;charset=%s', $mysql['host'] ?? '127.0.0.1', $mysql['port'] ?? 3306, $charset);
                new \PDO($dsn, $mysql['username'] ?? 'root', $mysql['password'] ?? '', [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]);
            } else {
                $path = $input['sqlite_path'] ?? (BASE_PATH.'/storage/data.sqlite');
                $dsn = 'sqlite:' . $path;
                new \PDO($dsn, null, null, [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]);
            }
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        return '';
    }

    public function dbPost()
    {
        $driver = $_POST['driver'] ?? 'mysql';
        $cfg = $GLOBALS['config'];
        $cfg['db']['driver'] = $driver;
        if ($driver === 'mysql') {
            $cfg['db']['mysql']['host'] = trim($_POST['host'] ?? '127.0.0.1');
            $cfg['db']['mysql']['port'] = (int)($_POST['port'] ?? 3306);
            $cfg['db']['mysql']['database'] = trim($_POST['database'] ?? 'gest2');
            $cfg['db']['mysql']['username'] = trim($_POST['username'] ?? 'root');
            $cfg['db']['mysql']['password'] = (string)($_POST['password'] ?? '');
        } else {
            $cfg['db']['sqlite_path'] = trim($_POST['sqlite_path'] ?? (BASE_PATH.'/storage/data.sqlite'));
        }
        // prova connessione e crea db se necessario
        try {
            DB::init($cfg['db']);
        } catch (\Throwable $e) {
            $_SESSION['install_errors']['db'] = ['Connessione fallita: '.$e->getMessage()];
            redirect('/install');
        }
        // salva config in config/app.php
        $this->writeConfig($cfg);
        // migra schema
        $schemaFile = ($cfg['db']['driver'] ?? 'sqlite') === 'mysql' ? BASE_PATH.'/database/schema.mysql.sql' : BASE_PATH.'/database/schema.sql';
        DB::migrate($schemaFile);
        redirect('/install/company');
        return '';
    }

    // STEP 2: Dati azienda e branding
    public function company()
    {
        $config = $GLOBALS['config'];
        $errors = $_SESSION['install_errors']['company'] ?? [];
        unset($_SESSION['install_errors']['company']);
        $env = $this->getEnvWarnings();
        render_install('install/company', compact('config','errors','env'));
        return '';
    }

    public function companyPost()
    {
        $name = trim($_POST['company_name'] ?? '');
        $email = trim($_POST['company_email'] ?? '');
        $phone = trim($_POST['company_phone'] ?? '');
        $address = trim($_POST['company_address'] ?? '');
        $primary = trim($_POST['brand_primary'] ?? '#0d6efd');
        $secondary = trim($_POST['brand_secondary'] ?? '#6610f2');
        if ($name === '') {
            $_SESSION['install_errors']['company'] = ['Il nome azienda è obbligatorio'];
            redirect('/install/company');
        }
        // gestisci upload logo opzionale
        $logoUrl = $GLOBALS['config']['app']['logo_url'] ?? '/assets/logo.svg';
        if (!empty($_FILES['company_logo']['tmp_name'])) {
            $ext = pathinfo($_FILES['company_logo']['name'], PATHINFO_EXTENSION) ?: 'png';
            $dest = '/assets/company-logo.' . strtolower($ext);
            $abs = BASE_PATH . '/public' . $dest;
            @mkdir(dirname($abs), 0777, true);
            @move_uploaded_file($_FILES['company_logo']['tmp_name'], $abs);
            if (is_file($abs)) {
                $logoUrl = $dest;
            }
        }
        $cfg = $GLOBALS['config'];
        $cfg['app']['name'] = $name;
        $cfg['app']['logo_url'] = $logoUrl;
        $cfg['app']['company_email'] = $email;
        $cfg['app']['company_phone'] = $phone;
        $cfg['app']['company_address'] = $address;
        $cfg['theme']['primary'] = $primary;
        $cfg['theme']['secondary'] = $secondary;
        $this->writeConfig($cfg);
        // Persistenza su DB (tabella companies)
        try {
            DB::init($cfg['db']);
            DB::execute('INSERT INTO companies (name,email,phone,address,logo_url,brand_primary,brand_secondary) VALUES (?,?,?,?,?,?,?)', [
                $name, $email, $phone, $address, $logoUrl, $primary, $secondary
            ]);
        } catch (\Throwable $e) {
            // ignora errori (tabella non esistente o altri)
        }
        redirect('/install/admin');
        return '';
    }

    // STEP 3: Admin iniziale
    public function admin()
    {
        $errors = $_SESSION['install_errors']['admin'] ?? [];
        unset($_SESSION['install_errors']['admin']);
        $config = $GLOBALS['config'];
        $env = $this->getEnvWarnings();
        render_install('install/admin', compact('errors','config','env'));
        return '';
    }

    public function adminPost()
    {
        $first = trim($_POST['first_name'] ?? '');
        $last = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $password2 = (string)($_POST['password_confirm'] ?? '');
        $errs = [];
        if ($first === '' || $last === '') $errs[] = 'Nome e cognome obbligatori';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'Email non valida';
        if (strlen($username) < 3) $errs[] = 'Username minimo 3 caratteri';
        if (strlen($password) < 8) $errs[] = 'Password minimo 8 caratteri';
        if ($password !== $password2) $errs[] = 'Le password non coincidono';
        if ($errs) {
            $_SESSION['install_errors']['admin'] = $errs;
            redirect('/install/admin');
        }
        // Assicura ruolo admin e crea utente
        try {
            // Inizializza connessione DB per questo step
            DB::init($GLOBALS['config']['db']);
            // Verifica/assicura lo schema necessario (roles/users) e forza migrazione se necessario
            $driver = DB::pdo()->getAttribute(\PDO::ATTR_DRIVER_NAME);
            $schemaFile = ($GLOBALS['config']['db']['driver'] ?? 'sqlite') === 'mysql' ? BASE_PATH.'/database/schema.mysql.sql' : BASE_PATH.'/database/schema.sql';
            try {
                DB::query('SELECT 1 FROM roles LIMIT 1');
            } catch (\Throwable $eSchema) {
                $flag = BASE_PATH . '/storage/.initialized_' . md5($schemaFile . '|' . $driver);
                if (is_file($flag)) { @unlink($flag); }
                DB::migrate($schemaFile);
            }

            $roleId = DB::query("SELECT id FROM roles WHERE name = 'admin' LIMIT 1")->fetch()['id'] ?? null;
            if (!$roleId) {
                DB::execute("INSERT INTO roles (name, description) VALUES ('admin','Amministratore')");
                $roleId = DB::pdo()->lastInsertId();
            }
            $pass = password_hash($password, PASSWORD_BCRYPT);
            $displayName = trim($first.' '.$last);
            // Prova inserimento con username (colonna potrebbe non esistere su DB già installati)
            try {
                DB::execute('INSERT INTO users (role_id, name, email, username, password, active) VALUES (?,?,?,?,?,1)', [
                    $roleId, $displayName, $email, $username, $pass
                ]);
            } catch (\Throwable $e2) {
                // fallback senza username
                DB::execute('INSERT INTO users (role_id, name, email, password, active) VALUES (?,?,?,?,1)', [
                    $roleId, $displayName, $email, $pass
                ]);
            }
        } catch (\Throwable $e) {
            $_SESSION['install_errors']['admin'] = ['Errore creazione admin: '.$e->getMessage()];
            redirect('/install/admin');
        }
        // Passo completato, mostra pagina di fine
        redirect('/install/finish');
        return '';
    }

    public function finish()
    {
        $config = $GLOBALS['config'];
        $env = $this->getEnvWarnings();
        render_install('install/finish', compact('config','env'));
        return '';
    }

    public function finishPost()
    {
        // Crea flag di completamento installazione
        $flagPath = BASE_PATH . '/storage/.installed';
        if (!is_dir(BASE_PATH . '/storage')) {
            @mkdir(BASE_PATH . '/storage', 0777, true);
        }
        @file_put_contents($flagPath, date('c'));
        // Invalida eventuali flag di inizializzazione DB per forzare controllo coerente al prossimo avvio
        // (manteniamo .initialized_* se già coerente con schema corrente)
        redirect('/login');
        return '';
    }

    private function writeConfig(array $cfg): void
    {
        $export = var_export($cfg, true);
        // Normalizza BASE_PATH in sqlite_path se presente
        $export = str_replace("'".BASE_PATH."'", 'BASE_PATH', $export);
        $php = "<?php\nreturn " . $export . ";\n";
        file_put_contents(BASE_PATH . '/config/app.php', $php);
        $GLOBALS['config'] = $cfg; // aggiorna runtime
    }

    private function getEnvWarnings(): array
    {
        $warnings = [];
        $paths = [
            'storage' => BASE_PATH . '/storage',
            'assets' => BASE_PATH . '/public/assets',
        ];
        foreach ($paths as $label => $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0777, true);
            }
            if (!is_writable($dir)) {
                $warnings[] = "La directory {$label} non è scrivibile: {$dir}. Impostare i permessi di scrittura.";
            }
        }
        return $warnings;
    }
}