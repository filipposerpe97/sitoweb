<?php
namespace App\Controllers;

use App\Core\DB;

class UsersController
{
    private function requireAuth(): void
    {
        if (empty($_SESSION['user'])) { redirect('/login'); }
    }

    private function roles(): array
    {
        return DB::query('SELECT id, name, description FROM roles ORDER BY name')->fetchAll();
    }

    private function dealers(): array
    {
        try { return DB::query('SELECT id, name FROM dealers ORDER BY name')->fetchAll(); }
        catch (\Throwable $e) { return []; }
    }

    private function generatePassword(int $length = 12): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%*?';
        $out = '';
        for ($i=0; $i<$length; $i++) { $out .= $chars[random_int(0, strlen($chars)-1)]; }
        return $out;
    }

    public function index()
    {
        $this->requireAuth();
        $q = trim($_GET['q'] ?? '');

        // Preferenze utente (sessione)
        if (!isset($_SESSION['users_prefs'])) { $_SESSION['users_prefs'] = []; }
        $prefs =& $_SESSION['users_prefs'];

        // Ordinamento sicuro
        $allowedSort = [
            'id' => 'u.id',
            'name' => 'u.name',
            'email' => 'u.email',
            'username' => 'u.username',
            'role' => 'r.name',
            'dealer' => 'd.name',
            'active' => 'u.active',
            'created' => 'u.created_at'
        ];
        $sortKey = $_GET['sort'] ?? ($prefs['sort'] ?? 'created');
        $sortCol = $allowedSort[$sortKey] ?? $allowedSort['created'];
        $dir = strtolower($_GET['dir'] ?? ($prefs['dir'] ?? 'desc'));
        $dir = in_array($dir, ['asc','desc'], true) ? $dir : 'desc';

        // Paginazione
        $perPage = max(5, min(100, (int)($_GET['per_page'] ?? ($prefs['per_page'] ?? 20))));
        $page = max(1, (int)($_GET['page'] ?? 1));
        $offset = ($page - 1) * $perPage;

        // Persisti preferenze
        $prefs['sort'] = $sortKey;
        $prefs['dir'] = $dir;
        $prefs['per_page'] = $perPage;

        // Filtro
        $where = '';
        $params = [];
        if ($q !== '') {
            $where = 'WHERE (u.name LIKE ? OR u.email LIKE ? OR u.username LIKE ?)';
            $like = '%' . $q . '%';
            $params = [$like, $like, $like];
        }

        // Conteggio totale
        $countSql = "SELECT COUNT(*) c FROM users u LEFT JOIN roles r ON u.role_id=r.id LEFT JOIN dealers d ON u.dealer_id=d.id $where";
        $total = (int)(DB::query($countSql, $params)->fetch()['c'] ?? 0);

        // Dati pagina
        $sql = "SELECT u.*, r.name role_name, d.name dealer_name
                FROM users u
                LEFT JOIN roles r ON u.role_id = r.id
                LEFT JOIN dealers d ON u.dealer_id = d.id
                $where ORDER BY $sortCol $dir LIMIT $perPage OFFSET $offset";
        $users = DB::query($sql, $params)->fetchAll();

        $totalPages = (int)ceil($total / $perPage);

        return render('users/index', [
            'page_title' => 'Utenti',
            'users' => $users,
            'q' => $q,
            'sort' => $sortKey,
            'dir' => $dir,
            'page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
        ]);
    }

    public function create()
    {
        $this->requireAuth();
        return render('users/form', [
            'page_title' => 'Nuovo utente',
            'roles' => $this->roles(),
            'dealers' => $this->dealers(),
            'user' => null,
            'errors' => [],
        ]);
    }

    public function store()
    {
        $this->requireAuth();
        $role_id = (int)($_POST['role_id'] ?? 0);
        $dealer_id = !empty($_POST['dealer_id']) ? (int)$_POST['dealer_id'] : null;
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $must_change = 1; // forza cambio al primo accesso
        $active = isset($_POST['active']) ? 1 : 0;
        $errors = [];

        if ($role_id <= 0) $errors['role_id'] = 'Seleziona un ruolo';
        if ($name === '') $errors['name'] = 'Nome obbligatorio';
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Email non valida';
        if ($username !== '' && strlen($username) < 3) $errors['username'] = 'Username troppo corto';

        $dup = DB::query('SELECT COUNT(*) c FROM users WHERE email = ?', [$email])->fetch();
        if ((int)$dup['c'] > 0) $errors['email'] = 'Email già in uso';
        if ($username !== '') {
            $dup2 = DB::query('SELECT COUNT(*) c FROM users WHERE username = ?', [$username])->fetch();
            if ((int)$dup2['c'] > 0) $errors['username'] = 'Username già in uso';
        }

        if (!empty($errors)) {
            return render('users/form', [
                'page_title' => 'Nuovo utente',
                'roles' => $this->roles(),
                'dealers' => $this->dealers(),
                'user' => $_POST,
                'errors' => $errors,
            ]);
        }

        if ($password === '') { $password = $this->generatePassword(12); }
        $hash = password_hash($password, PASSWORD_BCRYPT);
        DB::execute('INSERT INTO users (role_id, dealer_id, name, email, username, password, must_change_password, active) VALUES (?,?,?,?,?,?,?,?)', [
            $role_id, $dealer_id, $name, $email, $username !== '' ? $username : null, $hash, $must_change, $active
        ]);
        $id = DB::pdo()->lastInsertId();
        $_SESSION['last_user_plain_password'] = [ 'id' => $id, 'password' => $password ];
        $_SESSION['flash_success'] = 'Utente creato con successo';
        redirect('/users/edit?id=' . $id);
    }

    public function edit()
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $user = DB::query('SELECT * FROM users WHERE id = ?', [$id])->fetch();
        if (!$user) { $_SESSION['flash_error'] = 'Utente non trovato'; redirect('/users'); }
        return render('users/form', [
            'page_title' => 'Modifica utente',
            'roles' => $this->roles(),
            'dealers' => $this->dealers(),
            'user' => $user,
            'errors' => [],
        ]);
    }

    public function update()
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $role_id = (int)($_POST['role_id'] ?? 0);
        $dealer_id = !empty($_POST['dealer_id']) ? (int)$_POST['dealer_id'] : null;
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $active = isset($_POST['active']) ? 1 : 0;
        $errors = [];

        if ($role_id <= 0) $errors['role_id'] = 'Seleziona un ruolo';
        if ($name === '') $errors['name'] = 'Nome obbligatorio';
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Email non valida';
        if ($username !== '' && strlen($username) < 3) $errors['username'] = 'Username troppo corto';

        $dup = DB::query('SELECT COUNT(*) c FROM users WHERE email = ? AND id <> ?', [$email, $id])->fetch();
        if ((int)$dup['c'] > 0) $errors['email'] = 'Email già in uso';
        if ($username !== '') {
            $dup2 = DB::query('SELECT COUNT(*) c FROM users WHERE username = ? AND id <> ?', [$username, $id])->fetch();
            if ((int)$dup2['c'] > 0) $errors['username'] = 'Username già in uso';
        }

        if (!empty($errors)) {
            $user = $_POST; $user['id'] = $id;
            return render('users/form', [
                'page_title' => 'Modifica utente',
                'roles' => $this->roles(),
                'dealers' => $this->dealers(),
                'user' => $user,
                'errors' => $errors,
            ]);
        }

        DB::execute('UPDATE users SET role_id=?, dealer_id=?, name=?, email=?, username=?, active=? WHERE id=?', [
            $role_id, $dealer_id, $name, $email, $username !== '' ? $username : null, $active, $id
        ]);
        $_SESSION['flash_success'] = 'Utente aggiornato';
        redirect('/users/edit?id=' . $id);
    }

    public function toggle()
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $user = DB::query('SELECT active FROM users WHERE id = ?', [$id])->fetch();
        if ($user) {
            $new = ((int)$user['active'] === 1) ? 0 : 1;
            DB::execute('UPDATE users SET active = ? WHERE id = ?', [$new, $id]);
            $_SESSION['flash_success'] = 'Stato utente aggiornato';
        } else {
            $_SESSION['flash_error'] = 'Utente non trovato';
        }
        redirect('/users');
    }

    public function resetPassword()
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $newPass = $this->generatePassword(12);
        $hash = password_hash($newPass, PASSWORD_BCRYPT);
        DB::execute('UPDATE users SET password = ?, must_change_password = 1 WHERE id = ?', [$hash, $id]);
        $_SESSION['last_user_plain_password'] = [ 'id' => $id, 'password' => $newPass ];
        $_SESSION['flash_info'] = 'Password resettata. L\'utente dovrà cambiarla al primo accesso.';
        redirect('/users/edit?id=' . $id);
    }

    // Anteprima stampabile nel layout
    public function pdf()
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $user = DB::query('SELECT u.*, r.name role_name, r.description role_desc FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE u.id = ?', [$id])->fetch();
        if (!$user) { $_SESSION['flash_error'] = 'Utente non trovato'; redirect('/users'); }
        $plainPassword = null;
        if (!empty($_SESSION['last_user_plain_password']) && (int)$_SESSION['last_user_plain_password']['id'] === (int)$id) {
            $plainPassword = $_SESSION['last_user_plain_password']['password'];
        }
        return render('users/pdf', [
            'page_title' => 'Scheda utente',
            'user' => $user,
            'plainPassword' => $plainPassword,
        ]);
    }

    // Download PDF tramite Dompdf
    public function pdfDownload()
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $user = DB::query('SELECT u.*, r.name role_name, r.description role_desc FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE u.id = ?', [$id])->fetch();
        if (!$user) { $_SESSION['flash_error'] = 'Utente non trovato'; redirect('/users'); }
        $plainPassword = null;
        if (!empty($_SESSION['last_user_plain_password']) && (int)$_SESSION['last_user_plain_password']['id'] === (int)$id) {
            $plainPassword = $_SESSION['last_user_plain_password']['password'];
        }
        if (!class_exists('\\Dompdf\\Dompdf')) {
            $_SESSION['flash_error'] = 'Generatore PDF non disponibile. Installa le dipendenze con Composer (dompdf/dompdf).';
            redirect('/users/pdf?id=' . $id);
        }
        // Renderizzo la vista specifica per il PDF senza layout
        $params = ['user' => $user, 'plainPassword' => $plainPassword];
        extract($params);
        ob_start();
        require BASE_PATH . '/app/Views/users/pdf_raw.php';
        $html = ob_get_clean();

        $dompdf = new \Dompdf\Dompdf();
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $filename = 'utente_' . $id . '.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $dompdf->output();
        exit;
    }

    // Esportazione CSV elenco utenti (filtrato/ordinato)
    public function export()
    {
        $this->requireAuth();
        $q = trim($_GET['q'] ?? '');

        if (!isset($_SESSION['users_prefs'])) { $_SESSION['users_prefs'] = []; }
        $prefs = $_SESSION['users_prefs'];

        $allowedSort = [
            'id' => 'u.id',
            'name' => 'u.name',
            'email' => 'u.email',
            'username' => 'u.username',
            'role' => 'r.name',
            'dealer' => 'd.name',
            'active' => 'u.active',
            'created' => 'u.created_at'
        ];
        $sortKey = $_GET['sort'] ?? ($prefs['sort'] ?? 'created');
        $sortCol = $allowedSort[$sortKey] ?? $allowedSort['created'];
        $dir = strtolower($_GET['dir'] ?? ($prefs['dir'] ?? 'desc'));
        $dir = in_array($dir, ['asc','desc'], true) ? $dir : 'desc';

        $where = '';
        $params = [];
        if ($q !== '') {
            $where = 'WHERE (u.name LIKE ? OR u.email LIKE ? OR u.username LIKE ?)';
            $like = '%' . $q . '%';
            $params = [$like, $like, $like];
        }

        $sql = "SELECT u.id, u.name, u.email, u.username, r.name AS role_name, d.name AS dealer_name, u.active
                FROM users u
                LEFT JOIN roles r ON u.role_id = r.id
                LEFT JOIN dealers d ON u.dealer_id = d.id
                $where ORDER BY $sortCol $dir";
        $rows = DB::query($sql, $params)->fetchAll();

        $filename = 'utenti_' . date('Ymd_His') . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        // BOM per Excel UTF-8
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        // intestazioni
        fputcsv($out, ['ID','Nome','Email','Username','Ruolo','Dealer','Attivo'], ';');
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['id'],
                $r['name'],
                $r['email'],
                $r['username'],
                $r['role_name'],
                $r['dealer_name'],
                ((int)$r['active'] === 1 ? 'Si' : 'No')
            ], ';');
        }
        fclose($out);
        exit;
    }
}