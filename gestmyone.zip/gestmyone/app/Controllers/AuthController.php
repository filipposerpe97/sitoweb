<?php
namespace App\Controllers;

use App\Core\DB;

class AuthController
{
    public function login()
    {
        // Se già loggato, redirect alla dashboard
        if (!empty($_SESSION['user'])) {
            redirect('/');
        }

        $error = '';
        return render('auth/login', [
            'page_title' => 'Accesso',
            'error' => $error,
        ]);
    }

    public function doLogin()
    {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $error = '';

        // Rileva richieste AJAX/JSON
        $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
        $xhr = strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest';
        $isAjax = $xhr || strpos($accept, 'application/json') !== false || (($_POST['ajax'] ?? '') === '1');

        if (empty($email) || empty($password)) {
            $error = 'Compila tutti i campi';
        } else {
            // Verifica utente (email o username)
            $user = DB::query(
                'SELECT u.*, r.name as role_name, d.name as dealer_name 
                 FROM users u 
                 LEFT JOIN roles r ON u.role_id = r.id 
                 LEFT JOIN dealers d ON u.dealer_id = d.id 
                 WHERE (u.email = ? OR u.username = ?) AND u.active = 1',
                [$email, $email]
            )->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'username' => $user['username'] ?? null,
                    'role_name' => $user['role_name'],
                    'dealer_id' => $user['dealer_id'],
                    'dealer_name' => $user['dealer_name'] ?? null,
                ];
                $_SESSION['must_change_password'] = (int)($user['must_change_password'] ?? 0) === 1 ? 1 : 0;
                $redirectTo = !empty($_SESSION['must_change_password']) ? '/password/change' : '/';
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => true, 'redirect' => $redirectTo]);
                    return;
                }
                redirect($redirectTo);
            } else {
                $error = 'Credenziali non valide';
            }
        }

        if ($isAjax) {
            header('Content-Type: application/json');
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => $error, 'email' => $email]);
            return;
        }

        return render('auth/login', [
            'page_title' => 'Accesso',
            'error' => $error,
            'email' => $email,
        ]);
    }

    public function logout()
    {
        session_destroy();
        redirect('/login');
    }
}