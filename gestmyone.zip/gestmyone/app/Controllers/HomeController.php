<?php
namespace App\Controllers;

use App\Core\DB;

class HomeController
{
    public function index()
    {
        $counts = [
            'dealers' => 0,
            'stores' => 0,
            'terminals' => 0,
            'tickets' => 0,
        ];
        try {
            $counts['dealers'] = (int)(DB::query('SELECT COUNT(*) c FROM dealers')->fetch()['c'] ?? 0);
        } catch (\Throwable $e) {}
        try {
            $counts['stores'] = (int)(DB::query('SELECT COUNT(*) c FROM stores')->fetch()['c'] ?? 0);
        } catch (\Throwable $e) {}
        try {
            $counts['terminals'] = (int)(DB::query('SELECT COUNT(*) c FROM terminals')->fetch()['c'] ?? 0);
        } catch (\Throwable $e) {}
        try {
            $counts['tickets'] = (int)(DB::query('SELECT COUNT(*) c FROM tickets')->fetch()['c'] ?? 0);
        } catch (\Throwable $e) {}

        return render('home', [
            'page_title' => 'Dashboard',
            'counts' => $counts,
        ]);
    }
}