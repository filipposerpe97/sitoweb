<?php
namespace App\Controllers;

use App\Core\DB;

class PasswordController
{
    public function change()
    {
        if (empty($_SESSION['user'])) { redirect('/login'); }
        return render('password/change', [
            'page_title' => 'Cambio password',
            'error' => '',
        ]);
    }

    public function changePost()
    {
        if (empty($_SESSION['user'])) { redirect('/login'); }
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $error = '';

        if ($new !== $confirm) {
            $error = 'Le nuove password non coincidono';
        }
        if (strlen($new) < 8) {
            $error = 'La nuova password deve avere almeno 8 caratteri';
        }
        $user = DB::query('SELECT * FROM users WHERE id = ?', [$_SESSION['user']['id']])->fetch();
        if (!$user || !password_verify($current, $user['password'])) {
            $error = 'La password attuale non è corretta';
        }

        if ($error) {
            return render('password/change', [
                'page_title' => 'Cambio password',
                'error' => $error,
            ]);
        }

        $hash = password_hash($new, PASSWORD_BCRYPT);
        $driver = DB::pdo()->getAttribute(\PDO::ATTR_DRIVER_NAME);
        $now = ($driver === 'mysql') ? date('Y-m-d H:i:s') : date('c');
        DB::execute('UPDATE users SET password = ?, must_change_password = 0, password_changed_at = ? WHERE id = ?', [
            $hash, $now, $_SESSION['user']['id']
        ]);
        $_SESSION['must_change_password'] = 0;
        redirect('/');
    }
}