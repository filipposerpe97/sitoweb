<div class="row g-3">
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card border-0 shadow-sm">
      <div class="card-body d-flex align-items-center">
        <div class="me-3 text-primary"><i class="bi bi-buildings" style="font-size:2rem"></i></div>
        <div>
          <div class="text-muted small">Concessionari</div>
          <div class="fw-bold fs-4"><?= (int)($counts['dealers'] ?? 0) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card border-0 shadow-sm">
      <div class="card-body d-flex align-items-center">
        <div class="me-3 text-secondary"><i class="bi bi-shop" style="font-size:2rem"></i></div>
        <div>
          <div class="text-muted small">Punti Vendita</div>
          <div class="fw-bold fs-4"><?= (int)($counts['stores'] ?? 0) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card border-0 shadow-sm">
      <div class="card-body d-flex align-items-center">
        <div class="me-3 text-success"><i class="bi bi-pc-display" style="font-size:2rem"></i></div>
        <div>
          <div class="text-muted small">Terminali</div>
          <div class="fw-bold fs-4"><?= (int)($counts['terminals'] ?? 0) ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="card border-0 shadow-sm">
      <div class="card-body d-flex align-items-center">
        <div class="me-3 text-warning"><i class="bi bi-ticket-detailed" style="font-size:2rem"></i></div>
        <div>
          <div class="text-muted small">Ticket</div>
          <div class="fw-bold fs-4"><?= (int)($counts['tickets'] ?? 0) ?></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="card border-0 shadow-sm mt-4">
  <div class="card-body">
    <h2 class="h6 mb-3">Attività recenti</h2>
    <div class="text-muted">Nessuna attività ancora. Inizia creando concessionari, punti vendita e terminali.</div>
  </div>
</div>