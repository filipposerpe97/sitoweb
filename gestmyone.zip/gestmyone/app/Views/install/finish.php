<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Installazione - Completata</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root { --brand-primary: <?= htmlspecialchars(($config['theme']['primary'] ?? '#198754')) ?>; }
    body { background: #f5f7fb; }
    .brand-header { background: var(--brand-primary) !important; }
    .stepper .progress-bar { background: var(--brand-primary) !important; }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card shadow-sm">
          <div class="card-header brand-header text-white">
            <h1 class="h5 mb-0">Installazione completata</h1>
          </div>
          <div class="card-body">
            <div class="stepper mb-3">
              <ol class="list-unstyled d-flex justify-content-between small mb-2">
                <li>1. Database</li>
                <li>2. Azienda</li>
                <li>3. Admin</li>
                <li class="fw-semibold text-success">4. Fine</li>
              </ol>
              <div class="progress" style="height:6px;"><div class="progress-bar" style="width:100%"></div></div>
            </div>

            <?php if (!empty($env ?? [])): ?>
              <div class="alert alert-warning">
                <div class="fw-semibold mb-1">Controllo permessi</div>
                <ul class="mb-0">
                  <?php foreach (($env ?? []) as $w): ?><li><?= htmlspecialchars($w) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <p class="lead">L'applicazione è stata configurata correttamente.</p>
            <ul>
              <li>Configurazione database salvata</li>
              <li>Dati aziendali inseriti</li>
              <li>Utente amministratore creato</li>
            </ul>
            <form method="post" action="/install/finish" class="d-flex">
              <button class="btn btn-success ms-auto" type="submit">Vai al Login</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>