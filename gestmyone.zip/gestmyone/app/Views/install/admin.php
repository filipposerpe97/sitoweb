<?php /** @var array $errors */ ?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Installazione - Amministratore</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/css/app.css" rel="stylesheet">
  <style>
    :root { --brand-primary: <?= htmlspecialchars(($config['theme']['primary'] ?? '#0d6efd')) ?>; --brand-secondary: <?= htmlspecialchars(($config['theme']['secondary'] ?? '#6610f2')) ?>; }
    body { background: #f5f7fb; }
    .brand-header { background: var(--brand-primary) !important; }
    .stepper .progress-bar { background: var(--brand-primary) !important; }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card shadow-sm">
          <div class="card-header brand-header text-white">
            <h1 class="h5 mb-0">Wizard di Installazione - Passo 3/4: Utente Amministratore</h1>
          </div>
          <div class="card-body">
            <div class="stepper mb-3">
              <ol class="list-unstyled d-flex justify-content-between small mb-2">
                <li>1. Database</li>
                <li>2. Azienda</li>
                <li class="fw-semibold text-primary">3. Admin</li>
                <li>4. Fine</li>
              </ol>
              <div class="progress" style="height:6px;"><div class="progress-bar" style="width:75%"></div></div>
            </div>

            <?php if (!empty($env ?? [])): ?>
              <div class="alert alert-warning">
                <div class="fw-semibold mb-1">Controllo permessi</div>
                <ul class="mb-0">
                  <?php foreach (($env ?? []) as $w): ?><li><?= htmlspecialchars($w) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
              <div class="alert alert-danger">
                <ul class="mb-0">
                  <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <form method="post" action="/install/admin" id="adminForm" novalidate>
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Nome</label>
                  <input type="text" class="form-control" name="first_name" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Cognome</label>
                  <input type="text" class="form-control" name="last_name" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Email</label>
                  <input type="email" class="form-control" name="email" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Username</label>
                  <input type="text" class="form-control" name="username" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Password</label>
                  <input type="password" class="form-control" name="password" id="password" required minlength="6" autocomplete="new-password">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Conferma Password</label>
                  <input type="password" class="form-control" name="password_confirm" id="password_confirm" required minlength="6" autocomplete="new-password">
                  <div class="form-text text-danger d-none" id="pwMismatch">Le password non coincidono.</div>
                </div>
              </div>
              <div class="d-flex mt-4">
                <a class="btn btn-outline-secondary" href="/install/company">Indietro</a>
                <button class="btn btn-primary ms-auto" type="submit">Salva e continua</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="/assets/js/install.js"></script>
</body>
</html>