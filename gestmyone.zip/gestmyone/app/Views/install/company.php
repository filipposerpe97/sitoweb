<?php /** @var array $errors */ ?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Installazione - Dati Aziendali</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/css/app.css" rel="stylesheet">
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card shadow-sm">
          <div class="card-header brand-header text-white">
            <h1 class="h5 mb-0">Wizard di Installazione - Passo 2/4: Dati Aziendali</h1>
          </div>
          <div class="card-body">
            <div class="stepper mb-3">
              <ol class="list-unstyled d-flex justify-content-between small mb-2">
                <li>1. Database</li>
                <li class="fw-semibold text-primary">2. Azienda</li>
                <li>3. Admin</li>
                <li>4. Fine</li>
              </ol>
              <div class="progress" style="height:6px;"><div class="progress-bar" style="width:50%"></div></div>
            </div>

            <?php if (!empty($env ?? [])): ?>
              <div class="alert alert-warning">
                <div class="fw-semibold mb-1">Controllo permessi</div>
                <ul class="mb-0">
                  <?php foreach (($env ?? []) as $w): ?><li><?= htmlspecialchars($w) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
              <div class="alert alert-danger">
                <ul class="mb-0">
                  <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <form method="post" action="/install/company" enctype="multipart/form-data" id="companyForm">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Nome Azienda</label>
                  <input type="text" class="form-control" name="company_name" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Email Aziendale</label>
                  <input type="email" class="form-control" name="company_email">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Telefono</label>
                  <input type="text" class="form-control" name="company_phone">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Indirizzo</label>
                  <input type="text" class="form-control" name="company_address">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Colore Primario Brand</label>
                  <input type="color" class="form-control form-control-color" name="brand_primary" value="<?= htmlspecialchars($config['theme']['primary'] ?? '#0d6efd') ?>" title="Scegli colore">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Colore Secondario Brand</label>
                  <input type="color" class="form-control form-control-color" name="brand_secondary" value="<?= htmlspecialchars($config['theme']['secondary'] ?? '#6610f2') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Logo (SVG consigliato)</label>
                  <input type="file" class="form-control" name="company_logo" accept=".svg,.png,.jpg,.jpeg">
                  <div class="form-text">Se non caricato, verrà usato il logo di default.</div>
                  <div class="mt-2">
                    <img id="logoPreview" src="" alt="Anteprima Logo" style="max-height:48px; display:none; border:1px solid #dee2e6; padding:4px; background:#fff;">
                  </div>
                </div>
                <div class="col-12">
                  <div class="p-3 border rounded d-flex align-items-center justify-content-between">
                    <div>
                      <div class="fw-semibold">Anteprima tema</div>
                      <div class="text-muted small">I colori selezionati vengono applicati live.</div>
                    </div>
                    <div class="d-flex gap-2">
                      <button type="button" class="btn btn-brand">Azione primaria</button>
                      <button type="button" class="btn btn-outline-secondary">Azione secondaria</button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="d-flex mt-4">
                <a class="btn btn-outline-secondary" href="/install">Indietro</a>
                <button class="btn btn-primary ms-auto" type="submit">Salva e continua</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="/assets/js/install.js"></script>
</body>
</html>