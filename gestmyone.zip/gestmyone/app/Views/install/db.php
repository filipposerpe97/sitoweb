<?php /** @var array $config */ ?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Installazione - Configurazione Database</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/css/app.css" rel="stylesheet">
  <style>
    :root { --brand-primary: <?= htmlspecialchars($config['theme']['primary'] ?? '#0d6efd') ?>; --brand-secondary: <?= htmlspecialchars($config['theme']['secondary'] ?? '#6610f2') ?>; }
    body { background: #f5f7fb; }
    .brand-header { background: var(--brand-primary) !important; }
    .stepper .progress-bar { background: var(--brand-primary) !important; }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card shadow-sm">
          <div class="card-header brand-header text-white">
            <h1 class="h5 mb-0">Wizard di Installazione - Passo 1/4: Database</h1>
          </div>
          <div class="card-body">
            <div class="stepper mb-3">
              <ol class="list-unstyled d-flex justify-content-between small mb-2">
                <li class="fw-semibold text-primary">1. Database</li>
                <li>2. Azienda</li>
                <li>3. Admin</li>
                <li>4. Fine</li>
              </ol>
              <div class="progress" style="height:6px;"><div class="progress-bar" style="width:25%"></div></div>
            </div>

            <?php if (!empty($env ?? [])): ?>
              <div class="alert alert-warning">
                <div class="fw-semibold mb-1">Controllo permessi</div>
                <ul class="mb-0">
                  <?php foreach ($env as $w): ?><li><?= htmlspecialchars($w) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
              <div class="alert alert-danger">
                <ul class="mb-0">
                  <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <form method="post" action="/install" id="dbForm" novalidate>
              <div class="mb-3">
                <label class="form-label">Driver Database</label>
                <select class="form-select" name="driver" id="driver">
                  <option value="mysql" selected>MySQL / MariaDB</option>
                  <option value="sqlite">SQLite (file)</option>
                </select>
              </div>

              <div id="mysqlFields">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">Host</label>
                    <input type="text" class="form-control" name="host" value="<?= htmlspecialchars($config['db']['mysql']['host'] ?? '127.0.0.1') ?>" required>
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">Porta</label>
                    <input type="number" class="form-control" name="port" value="<?= htmlspecialchars((string)($config['db']['mysql']['port'] ?? 3306)) ?>" required>
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">Database</label>
                    <input type="text" class="form-control" name="database" value="<?= htmlspecialchars($config['db']['mysql']['database'] ?? 'gest2') ?>" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($config['db']['mysql']['username'] ?? 'root') ?>" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" value="<?= htmlspecialchars($config['db']['mysql']['password'] ?? '') ?>">
                  </div>
                </div>
              </div>

              <div id="sqliteFields" class="d-none">
                <label class="form-label">Percorso file SQLite</label>
                <input type="text" class="form-control" name="sqlite_path" value="<?= htmlspecialchars($config['db']['sqlite_path'] ?? (BASE_PATH . '/storage/data.sqlite')) ?>">
                <div class="form-text">Verrà creato se non esiste.</div>
              </div>

              <div class="d-flex align-items-center gap-3 mt-4">
                <button class="btn btn-outline-secondary" type="button" id="testBtn">Prova connessione</button>
                <button class="btn btn-primary" type="submit">Salva e continua</button>
                <div id="testResult" class="ms-auto small"></div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="/assets/js/install.js"></script>
</body>
</html>