<?php /** @var array $config */ ?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($config['app']['name']) ?><?= isset($page_title) ? ' - ' . htmlspecialchars($page_title) : '' ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="/assets/css/app.css" rel="stylesheet">
  <!-- Favicon full set -->
  <link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon-32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon-16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/assets/apple-touch-icon-180.png">
  <link rel="mask-icon" href="/assets/logo.svg" color="<?= htmlspecialchars($config['theme']['primary']) ?>">
  <link rel="shortcut icon" href="/favicon.ico">
  <meta name="color-scheme" content="light dark">
  <meta name="theme-color" media="(prefers-color-scheme: light)" content="<?= htmlspecialchars($config['theme']['primary']) ?>">
  <meta name="theme-color" media="(prefers-color-scheme: dark)" content="<?= htmlspecialchars($config['theme']['secondary']) ?>">
  <link rel="manifest" href="/site.webmanifest">
  <style>
    :root{
      --bs-primary: <?= $config['theme']['primary'] ?>;
      --bs-secondary: <?= $config['theme']['secondary'] ?>;
      --bs-success: <?= $config['theme']['success'] ?>;
      --bs-info: <?= $config['theme']['info'] ?>;
      --bs-warning: <?= $config['theme']['warning'] ?>;
      --bs-danger: <?= $config['theme']['danger'] ?>;
      --bs-light: <?= $config['theme']['light'] ?>;
      --bs-dark: <?= $config['theme']['dark'] ?>;
    }
    /* Fade-in solo del contenuto principale (main), header/sidebar stabili */
    .content-fade { transition: opacity .25s ease; }
    .content-fade.content-fade-initial { opacity: 0; }
  </style>
</head>
<?php $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); $isLogin = ($path === '/login'); ?>
<body class="<?= $isLogin ? 'bg-light' : '' ?>">
<?php if (!$isLogin): ?>
  <header class="navbar navbar-expand-lg navbar-dark bg-brand-gradient sticky-top shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center gap-2" href="/">
        <img src="<?= htmlspecialchars($config['app']['logo_url']) ?>" alt="Logo" style="height:32px;" onerror="this.onerror=null;this.src='/assets/logo.svg'"/>
        <span><?= htmlspecialchars($config['app']['name']) ?></span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topnav"><span class="navbar-toggler-icon"></span></button>
      <div class="collapse navbar-collapse" id="topnav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
          <li class="nav-item"><a class="nav-link" href="/reports"><i class="bi bi-graph-up"></i> Report</a></li>
          <li class="nav-item d-none d-lg-block"><span class="text-secondary mx-2">|</span></li>
          <?php if (!empty($_SESSION['user'])): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-circle me-2"></i>
                <span class="small">
                  <?= htmlspecialchars($_SESSION['user']['name'] ?? 'Utente') ?>
                  <span class="text-muted"><?php if (!empty($_SESSION['user']['role_name'])): ?>(<?= htmlspecialchars($_SESSION['user']['role_name']) ?>)<?php endif; ?></span>
                </span>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><h6 class="dropdown-header">Account</h6></li>
                <li><a class="dropdown-item" href="#"><i class="bi bi-gear me-2"></i>Impostazioni</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="/logout"><i class="bi bi-box-arrow-right me-2"></i>Esci</a></li>
              </ul>
            </li>
          <?php else: ?>
            <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="/login">Accedi</a></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </header>

  <div class="container-fluid">
    <div class="row">
      <?php $hideSidebar = ($path === '/login'); ?>
      <?php if (!$hideSidebar): ?>
      <aside class="col-12 col-md-3 col-lg-2 p-0 bg-light border-end min-vh-100">
        <nav class="list-group list-group-flush sticky-md-top py-3">
          <a href="/" class="list-group-item list-group-item-action <?= $path === '/' ? 'active' : '' ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
          <a href="/dealers" class="list-group-item list-group-item-action <?= $path === '/dealers' ? 'active' : '' ?>"><i class="bi bi-buildings me-2"></i>Concessionari</a>
          <a href="/stores" class="list-group-item list-group-item-action <?= $path === '/stores' ? 'active' : '' ?>"><i class="bi bi-shop me-2"></i>Punti Vendita</a>
          <a href="/rooms" class="list-group-item list-group-item-action <?= $path === '/rooms' ? 'active' : '' ?>"><i class="bi bi-grid-3x3-gap me-2"></i>Sale</a>
          <a href="/terminals" class="list-group-item list-group-item-action <?= $path === '/terminals' ? 'active' : '' ?>"><i class="bi bi-pc-display me-2"></i>Terminali</a>
          <a href="/peripherals" class="list-group-item list-group-item-action <?= $path === '/peripherals' ? 'active' : '' ?>"><i class="bi bi-usb-drive me-2"></i>Periferiche</a>
          <a href="/tickets" class="list-group-item list-group-item-action <?= $path === '/tickets' ? 'active' : '' ?>"><i class="bi bi-ticket-detailed me-2"></i>Ticket & Interventi</a>
          <a href="/reports" class="list-group-item list-group-item-action <?= $path === '/reports' ? 'active' : '' ?>"><i class="bi bi-graph-up-arrow me-2"></i>Report</a>
          <a href="/users" class="list-group-item list-group-item-action <?= ($path === '/users' || strpos($path,'/users/') === 0) ? 'active' : '' ?>"><i class="bi bi-people me-2"></i>Utenti</a>
        </nav>
      </aside>
      <?php endif; ?>
      <main class="<?= $hideSidebar ? 'col-12' : 'col-12 col-md-9 col-lg-10' ?> p-4 content-fade content-fade-initial">
        <?php if (!empty($page_title) && !$isLogin): ?>
        <div class="d-flex align-items-center justify-content-between mb-4">
          <h1 class="h4 m-0"><?= htmlspecialchars($page_title) ?></h1>
        </div>
        <?php endif; ?>
        
        <?php // Flash messages ?>
        <?php if (!empty($_SESSION['flash_success'])): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_SESSION['flash_success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
          <?php unset($_SESSION['flash_success']); ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['flash_error'])): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($_SESSION['flash_error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
          <?php unset($_SESSION['flash_error']); ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['flash_info'])): ?>
          <div class="alert alert-info alert-dismissible fade show" role="alert">
            <i class="bi bi-info-circle me-2"></i><?= htmlspecialchars($_SESSION['flash_info']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
          <?php unset($_SESSION['flash_info']); ?>
        <?php endif; ?>
        
        <?= $content ?? '' ?>
      </main>
    </div>
  </div>

  <footer class="bg-light border-top py-3 mt-auto">
    <div class="container-fluid small text-muted d-flex align-items-center justify-content-between">
      <div>
        <img src="<?= htmlspecialchars($config['app']['logo_url']) ?>" alt="Logo" style="height:20px;" onerror="this.onerror=null;this.src='/assets/logo.svg'"/>
        <span class="ms-2">© <?= date('Y') ?> <?= htmlspecialchars($config['app']['name']) ?></span>
      </div>
      <div>v0.1</div>
    </div>
  </footer>
<?php else: ?>
  <main class="container d-flex align-items-center justify-content-center" style="min-height:100vh;">
    <?= $content ?? '' ?>
  </main>
<?php endif; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <?php if (!$isLogin): ?>
  <script>
    // Fade-in all'ingresso: applicato solo al contenuto principale
    (function(){
      var main = document.querySelector('main.content-fade');
      if (!main) return;
      var remove = function(){ main.classList.remove('content-fade-initial'); };
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', remove);
      } else {
        requestAnimationFrame(remove);
      }
    })();

    // Fade-out in uscita per navigazioni interne: applicato solo al main
    (function(){
      var main = document.querySelector('main.content-fade');
      if (!main) return;

      function isInternalLink(a) {
        try {
          var url = new URL(a.href, window.location.origin);
          return url.origin === window.location.origin && (!url.hash) && (!a.target || a.target === '_self');
        } catch (e) { return false; }
      }

      function toMs(str) {
        if (!str) return 0;
        str = str.trim();
        return str.endsWith('ms') ? parseFloat(str) : parseFloat(str) * 1000;
      }

      function getTransitionMs(el) {
        var cs = getComputedStyle(el);
        var dur = (cs.transitionDuration || '0s').split(',')[0];
        var delay = (cs.transitionDelay || '0s').split(',')[0];
        return toMs(dur) + toMs(delay);
      }

      var duration = Math.max(150, getTransitionMs(main) || 250);

      document.addEventListener('click', function(e){
        if (e.defaultPrevented) return;
        // solo click primario senza modificatori
        if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

        var a = e.target.closest('a');
        if (!a) return;

        var href = a.getAttribute('href') || '';
        if (!href || href.charAt(0) === '#') return; // ancora/in-page
        if (a.hasAttribute('download')) return;      // download file
        if (a.hasAttribute('data-bs-toggle')) return; // toggler/bootstrap
        if (a.dataset && a.dataset.noTransition === 'true') return; // esclusioni esplicite
        if (!isInternalLink(a)) return;              // esterni o target diversi da _self

        e.preventDefault();
        // trigger fade-out solo del main
        main.classList.add('content-fade-initial');
        setTimeout(function(){
          window.location.href = a.href;
        }, duration);
      }, false);
    })();
  </script>
  <?php endif; ?>
</body>
</html>