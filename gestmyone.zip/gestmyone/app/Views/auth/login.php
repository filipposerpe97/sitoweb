<?php /** @var array $config */ ?>
<div class="row justify-content-center w-100">
  <div class="col-12 col-md-8 col-lg-5">
    <div class="card shadow-sm border-0">
      <div class="card-body p-4">
        <div class="text-center mb-3">
          <img src="<?= htmlspecialchars($config['app']['logo_url']) ?>" alt="Logo" style="height:48px" onerror="this.onerror=null;this.src='/assets/logo.svg'" />
        </div>
        <h1 class="h5 text-center mb-3">Accedi a <?= htmlspecialchars($config['app']['name']) ?></h1>

        <?php if (!empty($error)): ?>
          <div class="alert alert-danger py-2" role="alert" aria-live="assertive"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <div id="login-error" class="alert alert-danger py-2 d-none" role="alert" aria-live="assertive" tabindex="-1"></div>

        <form id="login-form" method="post" action="/login" novalidate>
          <div class="mb-3">
            <label class="form-label" for="email">Email o Username</label>
            <input id="email" type="text" name="email" class="form-control <?= !empty($error) ? 'is-invalid' : '' ?>" required value="<?= htmlspecialchars($email ?? '') ?>" placeholder="es: admin@local o admin" />
            <?php if (!empty($error)): ?>
              <div class="invalid-feedback">Controlla email o username.</div>
            <?php endif; ?>
          </div>
          <div class="mb-3">
            <label class="form-label" for="password">Password</label>
            <input id="password" type="password" name="password" class="form-control <?= !empty($error) ? 'is-invalid' : '' ?>" required />
            <?php if (!empty($error)): ?>
              <div class="invalid-feedback">Controlla la password.</div>
            <?php endif; ?>
          </div>
          <div class="d-grid">
            <button type="submit" class="btn btn-primary"><i class="bi bi-box-arrow-in-right me-1"></i> Accedi</button>
          </div>
        </form>

        <div class="small text-muted mt-3">
          Suggerimento: primo accesso con admin@local / ChangeMe!123
        </div>
      </div>
    </div>
    <div class="text-center text-muted small mt-3">
      © <?= date('Y') ?> <?= htmlspecialchars($config['app']['name']) ?>
    </div>
  </div>
</div>

<!-- Overlay loader a schermo intero -->
<style>
  #loader-overlay { position:fixed; inset:0; background:rgba(255,255,255,0.9); display:flex; align-items:center; justify-content:center; z-index:1050; opacity:0; pointer-events:none; transition: opacity .2s ease; }
  #loader-overlay.show { opacity: 1; pointer-events: auto; }
  @keyframes shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-6px)} 40%{transform:translateX(6px)} 60%{transform:translateX(-4px)} 80%{transform:translateX(4px)} }
  .shake { animation: shake .4s; }
  /* Transizione globale pagina */
  body.page-fade { transition: opacity .25s ease; }
  body.page-fade.fade-out { opacity: 0; }
</style>
<div id="loader-overlay">
  <div class="text-center">
    <img src="<?= htmlspecialchars($config['app']['logo_url']) ?>" alt="Logo" style="height:48px" onerror="this.onerror=null;this.src='/assets/logo.svg'"/>
    <div class="mt-3">
      <div class="spinner-border text-primary" role="status" aria-label="Caricamento"></div>
    </div>
    <div id="loader-text" class="mt-2 text-muted">Accesso in corso…</div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('login-form');
    const overlay = document.getElementById('loader-overlay');
    const loaderText = document.getElementById('loader-text');
    const card = document.querySelector('.card');
    const errorBox = document.getElementById('login-error');
    const emailInput = document.getElementById('email');
    const pwdInput = document.getElementById('password');

    // prepara transizione pagina
    document.body.classList.add('page-fade');

    // Se c'è un errore server-side, enfatizza il form e metti focus
    const hasSrvError = !!document.querySelector('.alert.alert-danger:not(#login-error)');
    if (hasSrvError && card) {
      card.classList.add('shake');
      if (emailInput) emailInput.focus();
    }

    if (!form || !overlay) return;
    form.addEventListener('submit', function(e) {
      e.preventDefault();

      // reset stato errori
      [emailInput, pwdInput].forEach(function(el){ if (!el) return; el.classList.remove('is-invalid'); el.removeAttribute('aria-invalid'); });
      if (errorBox) { errorBox.classList.add('d-none'); errorBox.textContent = ''; }

      // Validazione minima lato client
      const emailVal = (emailInput && emailInput.value || '').trim();
      const pwdVal = (pwdInput && pwdInput.value || '').trim();
      let clientError = '';
      if (!emailVal || !pwdVal) {
        clientError = 'Compila tutti i campi';
      }
      if (clientError) {
        if (!emailVal && emailInput) { emailInput.classList.add('is-invalid'); emailInput.setAttribute('aria-invalid', 'true'); }
        if (!pwdVal && pwdInput) { pwdInput.classList.add('is-invalid'); pwdInput.setAttribute('aria-invalid', 'true'); }
        if (errorBox) { errorBox.textContent = clientError; errorBox.classList.remove('d-none'); try { errorBox.focus(); } catch(e){} }
        if (card) { card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake'); }
        if (emailInput) emailInput.focus();
        return; // non procedere col fetch
      }

      // Disabilita il form e mostra il loader con fade-in
      const btn = form.querySelector('button[type="submit"]');
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Accesso in corso…';
      }
      Array.from(form.elements).forEach(function(el){
        if (el.tagName === 'BUTTON') return;
        el.setAttribute('aria-busy', 'true');
        try { el.setAttribute('readonly', 'readonly'); } catch(e){}
        el.classList.add('disabled');
      });
      overlay.classList.add('show');
      if (loaderText) loaderText.textContent = 'Accesso in corso…';

      // Submit AJAX
      const formData = new FormData(form);
      formData.set('ajax', '1');
      fetch('/login', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
        body: formData
      })
      .then(async (res) => {
        const data = await res.json().catch(() => null);
        if (res.ok && data && data.success) {
          if (loaderText) loaderText.textContent = 'Accesso effettuato, reindirizzamento…';
          // Fade-out overlay e pagina per transizione più fluida
          overlay.classList.remove('show');
          document.body.classList.add('fade-out');
          setTimeout(function(){ window.location.assign(data.redirect || '/'); }, 260);
          return;
        }
        const msg = (data && data.error) ? data.error : 'Credenziali non valide';
        throw new Error(msg);
      })
      .catch((err) => {
        // Errore: nascondi loader (fade-out), riattiva form e mostra messaggio
        overlay.classList.remove('show');
        document.body.classList.remove('fade-out');
        const btn = form.querySelector('button[type="submit"]');
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = '<i class="bi bi-box-arrow-in-right me-1"></i> Accedi';
        }
        Array.from(form.elements).forEach(function(el){
          el.removeAttribute('readonly');
          el.classList.remove('disabled');
          el.removeAttribute('aria-busy');
        });
        // Differenziazione: se è "Compila tutti i campi", evidenzia solo vuoti; altrimenti entrambi
        const isEmptyMsg = (err && err.message === 'Compila tutti i campi');
        if (emailInput) {
          if (isEmptyMsg ? !emailVal : true) emailInput.classList.add('is-invalid');
        }
        if (pwdInput) {
          if (isEmptyMsg ? !pwdVal : true) pwdInput.classList.add('is-invalid');
        }
        if (errorBox) {
          errorBox.textContent = err.message || 'Si è verificato un errore. Riprova.';
          errorBox.classList.remove('d-none');
          try { errorBox.focus(); } catch(e){}
        }
        if (card) {
          card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
        }
        if (emailInput) emailInput.focus();
      });
    });
  });
</script>