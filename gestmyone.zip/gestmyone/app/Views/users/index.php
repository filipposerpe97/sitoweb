<?php /** @var array $users */ ?>
<div class="container-fluid mt-3">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h1 class="h3 mb-0">Utenti</h1>
    <div class="d-flex gap-2">
      <?php 
        $exportParams = array_filter([
          'q' => $q ?? '',
          'sort' => $sort ?? 'created',
          'dir' => $dir ?? 'desc',
        ]);
        $exportUrl = '/users/export' . (!empty($exportParams) ? ('?' . http_build_query($exportParams)) : '');
      ?>
      <div class="dropdown">
        <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          Colonne
        </button>
        <div class="dropdown-menu p-3" style="min-width:240px;">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-id" data-col="id" checked>
            <label class="form-check-label" for="col-id">ID</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-name" data-col="name" checked>
            <label class="form-check-label" for="col-name">Nome</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-email" data-col="email" checked>
            <label class="form-check-label" for="col-email">Email</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-username" data-col="username" checked>
            <label class="form-check-label" for="col-username">Username</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-role" data-col="role" checked>
            <label class="form-check-label" for="col-role">Ruolo</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-dealer" data-col="dealer" checked>
            <label class="form-check-label" for="col-dealer">Dealer</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="col-active" data-col="active" checked>
            <label class="form-check-label" for="col-active">Attivo</label>
          </div>
        </div>
      </div>
      <a href="/users/create" class="btn btn-primary">Nuovo utente</a>
      <a href="<?=$exportUrl?>" class="btn btn-outline-success" data-no-transition="true"><i class="bi bi-filetype-csv me-1"></i>Esporta CSV</a>
    </div>
  </div>

  <form class="row g-2 mb-3" method="get" action="/users">
    <div class="col-auto">
      <input type="text" name="q" value="<?=htmlspecialchars($q ?? '')?>" class="form-control" placeholder="Cerca nome, email o username">
    </div>
    <div class="col-auto">
      <button class="btn btn-outline-secondary">Cerca</button>
    </div>
    <?php if ($q ?? ''): ?>
      <div class="col-auto">
        <a href="/users" class="btn btn-outline-warning">Reset</a>
      </div>
    <?php endif; ?>
    <div class="col-auto">
      <select name="per_page" class="form-select" onchange="this.form.submit()">
        <option value="20" <?=($per_page ?? 20) == 20 ? 'selected' : ''?>>20 per pagina</option>
        <option value="50" <?=($per_page ?? 20) == 50 ? 'selected' : ''?>>50 per pagina</option>
        <option value="100" <?=($per_page ?? 20) == 100 ? 'selected' : ''?>>100 per pagina</option>
      </select>
    </div>
    <!-- hidden per preserve search -->
    <input type="hidden" name="sort" value="<?=htmlspecialchars($sort ?? 'created')?>">
    <input type="hidden" name="dir" value="<?=htmlspecialchars($dir ?? 'desc')?>">
  </form>

  <div class="table-responsive">
    <table class="table table-striped align-middle" id="usersTable">
      <thead>
        <tr>
          <?php 
          $sortIcon = function($field) use ($sort, $dir) {
            if (($sort ?? 'created') === $field) {
              return ($dir ?? 'desc') === 'asc' ? ' <i class="bi bi-chevron-up"></i>' : ' <i class="bi bi-chevron-down"></i>';
            }
            return '';
          };
          $sortUrl = function($field) use ($q, $page, $per_page, $sort, $dir) {
            $newDir = (($sort ?? '') === $field && ($dir ?? '') === 'asc') ? 'desc' : 'asc';
            $params = array_filter([
              'q' => $q ?? '',
              'sort' => $field,
              'dir' => $newDir,
              'page' => $page ?? 1,
              'per_page' => $per_page ?? 20,
            ]);
            return '/users?' . http_build_query($params);
          };
          ?>
          <th class="col-id"><a href="<?=$sortUrl('id')?>" class="text-decoration-none">ID<?=$sortIcon('id')?></a></th>
          <th class="col-name"><a href="<?=$sortUrl('name')?>" class="text-decoration-none">Nome<?=$sortIcon('name')?></a></th>
          <th class="col-email"><a href="<?=$sortUrl('email')?>" class="text-decoration-none">Email<?=$sortIcon('email')?></a></th>
          <th class="col-username"><a href="<?=$sortUrl('username')?>" class="text-decoration-none">Username<?=$sortIcon('username')?></a></th>
          <th class="col-role"><a href="<?=$sortUrl('role')?>" class="text-decoration-none">Ruolo<?=$sortIcon('role')?></a></th>
          <th class="col-dealer"><a href="<?=$sortUrl('dealer')?>" class="text-decoration-none">Dealer<?=$sortIcon('dealer')?></a></th>
          <th class="col-active"><a href="<?=$sortUrl('active')?>" class="text-decoration-none">Attivo<?=$sortIcon('active')?></a></th>
          <th>Azioni</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td class="col-id"><?=$u['id']?></td>
            <td class="col-name"><?=htmlspecialchars($u['name'])?></td>
            <td class="col-email"><?=htmlspecialchars($u['email'])?></td>
            <td class="col-username"><?=htmlspecialchars($u['username'] ?? '')?></td>
            <td class="col-role"><?=htmlspecialchars($u['role_name'] ?? '')?></td>
            <td class="col-dealer"><?=htmlspecialchars($u['dealer_name'] ?? '')?></td>
            <td class="col-active">
              <?php if ((int)$u['active'] === 1): ?>
                <span class="badge bg-success">Si</span>
              <?php else: ?>
                <span class="badge bg-secondary">No</span>
              <?php endif; ?>
            </td>
            <td>
              <a class="btn btn-sm btn-outline-primary" href="/users/edit?id=<?=$u['id']?>">Modifica</a>
              <button type="button" class="btn btn-sm btn-outline-warning" data-action="toggle" data-user-id="<?=$u['id']?>" data-user-name="<?=htmlspecialchars($u['name'])?>" data-bs-toggle="modal" data-bs-target="#toggleModal">Attiva/Disattiva</button>
              <button type="button" class="btn btn-sm btn-outline-danger" data-action="resetpw" data-user-id="<?=$u['id']?>" data-user-name="<?=htmlspecialchars($u['name'])?>" data-bs-toggle="modal" data-bs-target="#resetPwModal">Reset PW</button>
              <a class="btn btn-sm btn-outline-secondary" href="/users/pdf?id=<?=$u['id']?>">PDF</a>
              <a class="btn btn-sm btn-outline-dark" href="/users/pdf-download?id=<?=$u['id']?>" data-no-transition="true">Scarica PDF</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if (($total_pages ?? 1) > 1): ?>
    <nav aria-label="Paginazione utenti">
      <ul class="pagination justify-content-center">
        <?php 
        $currentPage = $page ?? 1;
        $totalPages = $total_pages ?? 1;
        $pageUrl = function($p) use ($q, $sort, $dir, $per_page) {
          $params = array_filter([
            'q' => $q ?? '',
            'sort' => $sort ?? 'created',
            'dir' => $dir ?? 'desc',
            'page' => $p,
            'per_page' => $per_page ?? 20,
          ]);
          return '/users?' . http_build_query($params);
        };
        ?>
        
        <!-- Prima pagina -->
        <li class="page-item <?=$currentPage <= 1 ? 'disabled' : ''?>">
          <a class="page-link" href="<?=$pageUrl(1)?>">Prima</a>
        </li>
        
        <!-- Precedente -->
        <li class="page-item <?=$currentPage <= 1 ? 'disabled' : ''?>">
          <a class="page-link" href="<?=$pageUrl($currentPage - 1)?>">Prec</a>
        </li>
        
        <!-- Numeri di pagina -->
        <?php 
        $start = max(1, $currentPage - 2);
        $end = min($totalPages, $currentPage + 2);
        for ($i = $start; $i <= $end; $i++): 
        ?>
          <li class="page-item <?=$i === $currentPage ? 'active' : ''?>">
            <a class="page-link" href="<?=$pageUrl($i)?>"><?=$i?></a>
          </li>
        <?php endfor; ?>
        
        <!-- Successiva -->
        <li class="page-item <?=$currentPage >= $totalPages ? 'disabled' : ''?>">
          <a class="page-link" href="<?=$pageUrl($currentPage + 1)?>">Succ</a>
        </li>
        
        <!-- Ultima pagina -->
        <li class="page-item <?=$currentPage >= $totalPages ? 'disabled' : ''?>">
          <a class="page-link" href="<?=$pageUrl($totalPages)?>">Ultima</a>
        </li>
      </ul>
    </nav>
    
    <div class="text-center text-muted">
      Mostrando <?=count($users)?> di <?=$total ?? 0?> utenti (pagina <?=$currentPage?> di <?=$totalPages?>)
    </div>
  <?php endif; ?>

  <!-- Modale conferma toggle attivo -->
  <div class="modal fade" id="toggleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Conferma cambio stato</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="post" action="/users/toggle" id="toggleForm">
          <div class="modal-body">
            <input type="hidden" name="id" id="toggleUserId">
            <p>Confermi di invertire lo stato attivo per l'utente <strong id="toggleUserName"></strong>?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annulla</button>
            <button type="submit" class="btn btn-warning">Conferma</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modale conferma reset password -->
  <div class="modal fade" id="resetPwModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Conferma reset password</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="post" action="/users/reset-password" id="resetPwForm">
          <div class="modal-body">
            <input type="hidden" name="id" id="resetUserId">
            <p>Confermi il reset password per l'utente <strong id="resetUserName"></strong>? Sarà richiesto il cambio al primo accesso.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annulla</button>
            <button type="submit" class="btn btn-danger">Resetta</button>
          </div>
        </form>
      </div>
    </div>
  </div>

</div>

<script>
(function(){
  // Gestione colonne visibili con localStorage
  const COLS = ['id','name','email','username','role','dealer','active'];
  const key = 'users_table_columns';
  const table = document.getElementById('usersTable');
  function getPrefs(){
    try { return JSON.parse(localStorage.getItem(key)) || {}; } catch(e){ return {}; }
  }
  function savePrefs(p){ localStorage.setItem(key, JSON.stringify(p)); }
  function applyPrefs(){
    const prefs = getPrefs();
    COLS.forEach(col => {
      const visible = (prefs[col] !== false); // default true
      // checkboxes
      const cb = document.querySelector(`input[data-col="${col}"]`);
      if (cb) cb.checked = visible;
      // headers
      table.querySelectorAll(`.col-${col}`).forEach(el => {
        el.style.display = visible ? '' : 'none';
      });
    });
  }
  document.querySelectorAll('.dropdown-menu input[data-col]').forEach(cb => {
    cb.addEventListener('change', function(){
      const prefs = getPrefs();
      prefs[this.dataset.col] = this.checked; // true/false
      savePrefs(prefs);
      applyPrefs();
    });
  });
  applyPrefs();

  // Modali conferma
  const toggleModal = document.getElementById('toggleModal');
  const resetModal = document.getElementById('resetPwModal');
  if (toggleModal) {
    toggleModal.addEventListener('show.bs.modal', function(ev){
      const btn = ev.relatedTarget;
      const id = btn?.getAttribute('data-user-id') || '';
      const name = btn?.getAttribute('data-user-name') || '';
      document.getElementById('toggleUserId').value = id;
      document.getElementById('toggleUserName').textContent = name;
    });
  }
  if (resetModal) {
    resetModal.addEventListener('show.bs.modal', function(ev){
      const btn = ev.relatedTarget;
      const id = btn?.getAttribute('data-user-id') || '';
      const name = btn?.getAttribute('data-user-name') || '';
      document.getElementById('resetUserId').value = id;
      document.getElementById('resetUserName').textContent = name;
    });
  }
})();
</script>