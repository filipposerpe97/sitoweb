<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <title>Scheda utente</title>
  <style>
    @page { margin: 24mm 18mm; }
    body { font-family: DejaVu Sans, Arial, Helvetica, sans-serif; font-size: 12px; color: #222; }
    h1 { font-size: 20px; margin: 0 0 10px; }
    .muted { color: #666; font-size: 11px; }
    .card { border: 1px solid #ccc; border-radius: 6px; margin-top: 12px; }
    .card-body { padding: 12px 14px; }
    .row { display: flex; flex-wrap: wrap; margin: -6px; }
    .col { padding: 6px; box-sizing: border-box; }
    .col-6 { width: 50%; }
    .fw { font-weight: 600; }
    .mt-2 { margin-top: 8px; }
    .mt-3 { margin-top: 12px; }
    .mb-1 { margin-bottom: 4px; }
    .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 11px; }
    .badge-success { background: #198754; color: #fff; }
    .badge-secondary { background: #6c757d; color: #fff; }
    .title-bar { display:flex; align-items:center; justify-content:space-between; }
  </style>
</head>
<body>
  <div class="title-bar">
    <h1>Scheda utente</h1>
    <div class="muted">Generata il <?=date('d/m/Y H:i')?> </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <div class="row">
        <div class="col col-6">
          <div class="mb-1"><span class="fw">Nome</span>: <?=htmlspecialchars($user['name'])?></div>
          <div class="mb-1"><span class="fw">Email</span>: <?=htmlspecialchars($user['email'])?></div>
          <div class="mb-1"><span class="fw">Username</span>: <?=htmlspecialchars($user['username'] ?? '')?></div>
        </div>
        <div class="col col-6">
          <div class="mb-1"><span class="fw">Ruolo</span>: <?=htmlspecialchars($user['role_name'] ?? '')?></div>
          <div class="mb-1"><span class="fw">Stato</span>: <?=(int)$user['active']===1?'<span class="badge badge-success">Attivo</span>':'<span class="badge badge-secondary">Disattivo</span>'?></div>
          <div class="mb-1"><span class="fw">Dealer</span>: <?=htmlspecialchars($user['dealer_id'] ?? '')?></div>
        </div>
      </div>
    </div>
  </div>

  <?php if (!empty($plainPassword)): ?>
  <div class="card mt-3">
    <div class="card-body">
      <div><span class="fw">Password temporanea</span>: <span style="font-weight:700;"><?=htmlspecialchars($plainPassword)?></span>. La password dovrà essere cambiata al primo accesso.</div>
    </div>
  </div>
  <?php endif; ?>

  <div class="card mt-3">
    <div class="card-body">
      <div class="fw mb-1">Permessi ruolo</div>
      <div><?=nl2br(htmlspecialchars($user['role_desc'] ?? ''))?></div>
    </div>
  </div>
</body>
</html>