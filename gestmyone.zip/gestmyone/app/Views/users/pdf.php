<?php /** @var array $user */ ?>
<div class="container mt-3">
  <div class="d-flex justify-content-between align-items-center">
    <h1 class="h4 m-0">Scheda utente</h1>
    <button class="btn btn-outline-secondary" onclick="window.print()"><i class="bi bi-printer me-1"></i> Stampa</button>
  </div>
  <div class="text-muted">Generata il <?=date('d/m/Y H:i')?> </div>

  <div class="card mt-3">
    <div class="card-body">
      <div class="row g-3">
        <div class="col-md-6">
          <div><strong>Nome</strong>: <?=htmlspecialchars($user['name'])?></div>
          <div><strong>Email</strong>: <?=htmlspecialchars($user['email'])?></div>
          <div><strong>Username</strong>: <?=htmlspecialchars($user['username'] ?? '')?></div>
        </div>
        <div class="col-md-6">
          <div><strong>Ruolo</strong>: <?=htmlspecialchars($user['role_name'] ?? '')?></div>
          <div><strong>Stato</strong>: <?=((int)$user['active']===1?'Attivo':'Disattivo')?></div>
          <div><strong>Dealer</strong>: <?=htmlspecialchars($user['dealer_id'] ?? '')?></div>
        </div>
      </div>
    </div>
  </div>

  <?php if (!empty($plainPassword)): ?>
  <div class="alert alert-info mt-3">
    Password temporanea: <strong><?=htmlspecialchars($plainPassword)?></strong>. La password dovrà essere cambiata al primo accesso.
  </div>
  <?php endif; ?>

  <div class="card mt-3">
    <div class="card-body">
      <div class="fw-semibold mb-2">Permessi ruolo</div>
      <div><?=nl2br(htmlspecialchars($user['role_desc'] ?? ''))?></div>
    </div>
  </div>
</div>
<style>
  @media print {
    header, footer, aside, nav { display: none !important; }
    main { padding: 0 !important; }
    .btn { display: none !important; }
  }
</style>