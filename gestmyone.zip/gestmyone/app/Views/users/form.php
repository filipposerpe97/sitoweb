<?php /** @var array|null $user */ ?>
<div class="container mt-3">
  <h1 class="h3 mb-3"><?= $user ? 'Modifica utente' : 'Nuovo utente' ?></h1>

  <form method="post" action="<?= $user ? '/users/update' : '/users' ?>">
    <?php if ($user): ?>
      <input type="hidden" name="id" value="<?=$user['id']?>">
    <?php endif; ?>

    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Nome</label>
        <input type="text" name="name" class="form-control" value="<?=htmlspecialchars($user['name'] ?? ($_POST['name'] ?? ''))?>">
        <?php if (!empty($errors['name'])): ?><div class="text-danger small"><?=$errors['name']?></div><?php endif; ?>
      </div>
      <div class="col-md-6">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?=htmlspecialchars($user['email'] ?? ($_POST['email'] ?? ''))?>">
        <?php if (!empty($errors['email'])): ?><div class="text-danger small"><?=$errors['email']?></div><?php endif; ?>
      </div>

      <div class="col-md-4">
        <label class="form-label">Username (opzionale)</label>
        <input type="text" name="username" class="form-control" value="<?=htmlspecialchars($user['username'] ?? ($_POST['username'] ?? ''))?>">
        <?php if (!empty($errors['username'])): ?><div class="text-danger small"><?=$errors['username']?></div><?php endif; ?>
      </div>

      <div class="col-md-4">
        <label class="form-label">Ruolo</label>
        <select name="role_id" class="form-select">
          <option value="">Seleziona...</option>
          <?php foreach ($roles as $r): ?>
            <option value="<?=$r['id']?>" <?=(int)($user['role_id'] ?? ($_POST['role_id'] ?? 0)) === (int)$r['id'] ? 'selected' : ''?>><?=htmlspecialchars($r['name'])?></option>
          <?php endforeach; ?>
        </select>
        <?php if (!empty($errors['role_id'])): ?><div class="text-danger small"><?=$errors['role_id']?></div><?php endif; ?>
      </div>

      <div class="col-md-4">
        <label class="form-label">Dealer (opzionale)</label>
        <select name="dealer_id" class="form-select">
          <option value="">Nessuno</option>
          <?php foreach ($dealers as $d): ?>
            <option value="<?=$d['id']?>" <?=(int)($user['dealer_id'] ?? ($_POST['dealer_id'] ?? 0)) === (int)$d['id'] ? 'selected' : ''?>><?=htmlspecialchars($d['name'])?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <?php if (!$user): ?>
      <div class="col-md-6">
        <label class="form-label">Password iniziale (vuoto = generata)</label>
        <input type="text" name="password" class="form-control" value="">
      </div>
      <?php endif; ?>

      <div class="col-md-2 d-flex align-items-center">
        <div class="form-check mt-4">
          <input class="form-check-input" type="checkbox" name="active" value="1" <?=((int)($user['active'] ?? 1) === 1) ? 'checked' : ''?>>
          <label class="form-check-label">Attivo</label>
        </div>
      </div>
    </div>

    <div class="mt-4 d-flex gap-2">
      <button class="btn btn-primary">Salva</button>
      <a href="/users" class="btn btn-secondary">Annulla</a>
    </div>
  </form>

  <?php if ($user): ?>
    <div class="mt-3 d-flex gap-2">
      <form method="post" action="/users/reset-password" class="d-inline">
        <input type="hidden" name="id" value="<?=$user['id']?>">
        <button class="btn btn-outline-danger" onclick="return confirm('Reset password e forza cambio al login?')">Reset Password</button>
      </form>
      <a href="/users/pdf?id=<?=$user['id'] ?>" class="btn btn-outline-secondary">PDF</a>
      <a href="/users/pdf-download?id=<?=$user['id'] ?>" class="btn btn-outline-dark" data-no-transition="true">Scarica PDF</a>
      <?php if (!empty($_SESSION['last_user_plain_password']) && (int)$_SESSION['last_user_plain_password']['id'] === (int)$user['id']): ?>
        <a href="/users/pdf?id=<?=$user['id'] ?>" class="btn btn-outline-secondary">Scarica PDF</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['last_user_plain_password']) && (!$user || (int)$_SESSION['last_user_plain_password']['id'] === (int)$user['id'])): ?>
    <div class="alert alert-info mt-3">
      Password temporanea: <strong><?=htmlspecialchars($_SESSION['last_user_plain_password']['password'])?></strong>. Viene richiesta la modifica al primo accesso.
    </div>
  <?php endif; ?>
</div>