<div class="text-center p-5 border-2 border-dashed rounded-3 bg-light">
  <div class="mb-3"><i class="bi bi-tools" style="font-size:3rem;color:var(--bs-secondary)"></i></div>
  <h2 class="h5 mb-2"><?= htmlspecialchars($page_title ?? 'Sezione') ?></h2>
  <p class="text-muted">La sezione è in fase di sviluppo. Presto potrai gestire tutte le funzioni richieste (CRUD, flussi, report, export).</p>
  <a href="/" class="btn btn-primary"><i class="bi bi-speedometer2 me-1"></i> Torna alla Dashboard</a>
</div>