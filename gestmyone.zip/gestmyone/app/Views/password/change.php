<?php /** @var array $error */ ?>
<div class="container mt-4">
  <h1 class="mb-4">Cambio password</h1>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?=$error?></div>
  <?php endif; ?>
  <form method="post" action="/password/change">
    <div class="mb-3">
      <label class="form-label">Password attuale</label>
      <input type="password" name="current_password" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nuova password</label>
      <input type="password" name="new_password" class="form-control" required minlength="8">
      <div class="form-text">Almeno 8 caratteri, includere lettere e numeri</div>
    </div>
    <div class="mb-3">
      <label class="form-label">Conferma nuova password</label>
      <input type="password" name="confirm_password" class="form-control" required minlength="8">
    </div>
    <button class="btn btn-primary">Salva</button>
  </form>
</div>