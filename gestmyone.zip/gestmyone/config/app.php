<?php
return array (
  'app' => 
  array (
    'name' => 'MYONE SRL',
    'logo_url' => '/assets/company-logo.png',
    'company_email' => 'info@myonesrl.it',
    'company_phone' => '',
    'company_address' => 'VIA DELL\'AGRICOLURA 3 - 37012 BUSSOLENGO (VR)',
  ),
  'theme' => 
  array (
    'primary' => '#2f66b3',
    'secondary' => '#0f3555',
    'success' => '#198754',
    'info' => '#0dcaf0',
    'warning' => '#ffc107',
    'danger' => '#dc3545',
    'light' => '#f5f7fb',
    'dark' => '#212529',
  ),
  'db' => 
  array (
    'driver' => 'mysql',
    'sqlite_path' => 'C:\\wamp64\\www\\gest2/storage/data.sqlite',
    'mysql' => 
    array (
      'host' => 'localhost',
      'port' => 3306,
      'database' => 'gest2',
      'username' => 'root',
      'password' => '',
      'charset' => 'utf8mb4',
      'collation' => 'utf8mb4_general_ci',
    ),
  ),
);
